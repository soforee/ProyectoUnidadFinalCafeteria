
package pe.edu.upeu.model;

public class pedido {
    private int idpedido;
    private int mesa;
    private double total;
    private String estado;
    private String fecha;

    public pedido() {
    }

    public pedido(int idpedido, int mesa, double total, String estado, String fecha) {
        this.idpedido = idpedido;
        this.mesa = mesa;
        this.total = total;
        this.estado = estado;
        this.fecha = fecha;
    }

    public int getIdpedido() {
        return idpedido;
    }

    public void setIdpedido(int idpedido) {
        this.idpedido = idpedido;
    }

    public int getMesa() {
        return mesa;
    }

    public void setMesa(int mesa) {
        this.mesa = mesa;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    
}
