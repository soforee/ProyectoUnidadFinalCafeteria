
package pe.edu.upeu.model;

public class catalogo {
    private int idproducto;
    private double precio;
    private String nameProduct;
    private String tipo;

    public catalogo() {
    }

    public catalogo(int idproducto, double precio, String nameProduct, String tipo) {
        this.idproducto = idproducto;
        this.precio = precio;
        this.nameProduct = nameProduct;
        this.tipo = tipo;
    }

    public int getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(int idproducto) {
        this.idproducto = idproducto;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getNameProduct() {
        return nameProduct;
    }

    public void setNameProduct(String nameProduct) {
        this.nameProduct = nameProduct;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
    
}
