
package pe.edu.upeu.model;

public class usuario extends persona{
    private int idusuario;
    private String usuario;
    private String clave;
    private String genero;

    public usuario() {
    }

    public usuario(int idusuario, String usuario, String clave, String genero, String nombre, String apellidos, String dni) {
        super(nombre, apellidos, dni);
        this.idusuario = idusuario;
        this.usuario = usuario;
        this.clave = clave;
        this.genero = genero;
    }

    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    
}
