
package pe.edu.upeu.interfaces;

import java.util.List;
import pe.edu.upeu.model.catalogo;

public interface iCatalogoDao {
    public boolean insertar (catalogo ca);
    public List<catalogo> listar();
    public boolean editar(catalogo ca);
    public boolean eliminar(catalogo ca);
    public catalogo BuscarPorId(int id);
}
