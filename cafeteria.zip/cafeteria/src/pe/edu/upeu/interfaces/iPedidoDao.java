
package pe.edu.upeu.interfaces;

import java.util.List;
import pe.edu.upeu.model.pedido;

public interface iPedidoDao {
    public boolean insertar (pedido p);
    public List<pedido> listar();
    public boolean editar(pedido p);
    public boolean eliminar(pedido p);
    public pedido BuscarPorId(int id);
}
