
package pe.edu.upeu.interfaces;

import java.util.List;
import pe.edu.upeu.model.usuario;

public interface iUsuarioDao {
    public boolean insertar (usuario u);
    public List<usuario> listar();
    public boolean editar(usuario u);
    public boolean eliminar(usuario u);
    public usuario BuscarPorId(int id);
}
