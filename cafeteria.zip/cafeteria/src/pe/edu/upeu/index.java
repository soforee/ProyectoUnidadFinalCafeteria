
package pe.edu.upeu;

import pe.edu.upeu.vista.login;

public class index {

    public static void main(String[] args) {
        login l = new login();
        
        
        l.setVisible(true);
        l.setLocationRelativeTo(null);
    }
    
}
