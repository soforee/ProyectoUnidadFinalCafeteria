package pe.edu.upeu.vista;

import java.awt.Image;
import java.awt.Toolkit;
import java.sql.*;
import javax.swing.JOptionPane;
import pe.edu.upeu.utils.ConexionBD;

public class login extends javax.swing.JFrame {

    public login() {
        initComponents();
        setIconImage(getIconImage());

    }

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("pe/edu/upeu/resources/img/logo.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        lb_derecha = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lb_izquierda = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        lb_icono = new javax.swing.JLabel();
        lb_titulo = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lb_contraseña = new javax.swing.JPanel();
        Lb_login = new javax.swing.JLabel();
        txt_usuario = new javax.swing.JTextField();
        txt_pass = new javax.swing.JPasswordField();
        lb_usuario = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        ch_remember = new javax.swing.JCheckBox();
        bt_login = new javax.swing.JButton();
        lb_textoregistro = new javax.swing.JLabel();
        bt_register = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 304, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jButton1.setText("jButton1");

        lb_derecha.setBackground(new java.awt.Color(137, 87, 55));

        javax.swing.GroupLayout lb_derechaLayout = new javax.swing.GroupLayout(lb_derecha);
        lb_derecha.setLayout(lb_derechaLayout);
        lb_derechaLayout.setHorizontalGroup(
            lb_derechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 324, Short.MAX_VALUE)
        );
        lb_derechaLayout.setVerticalGroup(
            lb_derechaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(137, 87, 55));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 305, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        lb_izquierda.setBackground(new java.awt.Color(243, 233, 220));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/logoinicio.png"))); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout lb_izquierdaLayout = new javax.swing.GroupLayout(lb_izquierda);
        lb_izquierda.setLayout(lb_izquierdaLayout);
        lb_izquierdaLayout.setHorizontalGroup(
            lb_izquierdaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lb_izquierdaLayout.createSequentialGroup()
                .addGap(108, 108, 108)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(323, Short.MAX_VALUE))
        );
        lb_izquierdaLayout.setVerticalGroup(
            lb_izquierdaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lb_izquierdaLayout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(jLabel1)
                .addContainerGap(284, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(243, 233, 220));

        jPanel3.setBackground(new java.awt.Color(243, 233, 220));
        jPanel3.setPreferredSize(new java.awt.Dimension(650, 450));

        jPanel4.setBackground(new java.awt.Color(243, 233, 220));

        lb_icono.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/logoinicio.png"))); // NOI18N
        lb_icono.setText("jLabel2");

        lb_titulo.setFont(new java.awt.Font("Intro ", 0, 36)); // NOI18N
        lb_titulo.setForeground(new java.awt.Color(94, 48, 35));
        lb_titulo.setText("MikunaWasi");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/inicio.png"))); // NOI18N
        jLabel3.setText("jLabel3");

        jLabel4.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(137, 87, 55));
        jLabel4.setText("Copyright © 2025 MikunaWasi. Todos los derechos reservados.");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(153, 153, 153)
                .addComponent(lb_icono, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(75, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(189, 189, 189))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lb_titulo)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lb_icono)
                .addGap(18, 18, 18)
                .addComponent(lb_titulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(36, 36, 36))
        );

        lb_contraseña.setBackground(new java.awt.Color(137, 87, 55));
        lb_contraseña.setFont(new java.awt.Font("Intro ", 0, 18)); // NOI18N

        Lb_login.setFont(new java.awt.Font("Intro ", 0, 24)); // NOI18N
        Lb_login.setText("INICIO SESIÓN");

        txt_usuario.setBackground(new java.awt.Color(192, 133, 82));
        txt_usuario.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_usuario.setForeground(new java.awt.Color(94, 48, 35));
        txt_usuario.setBorder(null);
        txt_usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_usuarioActionPerformed(evt);
            }
        });

        txt_pass.setBackground(new java.awt.Color(192, 133, 82));
        txt_pass.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_pass.setForeground(new java.awt.Color(94, 48, 35));
        txt_pass.setBorder(null);

        lb_usuario.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        lb_usuario.setText("USUARIO");

        jLabel2.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        jLabel2.setText("PASSWORD");

        ch_remember.setBackground(new java.awt.Color(137, 87, 55));
        ch_remember.setFont(new java.awt.Font("Intro ", 0, 8)); // NOI18N
        ch_remember.setText("Recuerdame");

        bt_login.setBackground(new java.awt.Color(94, 48, 35));
        bt_login.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        bt_login.setText("LOGIN");
        bt_login.setBorder(null);
        bt_login.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_loginMouseClicked(evt);
            }
        });
        bt_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_loginActionPerformed(evt);
            }
        });

        lb_textoregistro.setText("Si no tiene cuenta, registrate aquí");

        bt_register.setBackground(new java.awt.Color(94, 48, 35));
        bt_register.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        bt_register.setText("REGISTER");
        bt_register.setBorder(null);
        bt_register.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bt_registerMouseClicked(evt);
            }
        });
        bt_register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_registerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout lb_contraseñaLayout = new javax.swing.GroupLayout(lb_contraseña);
        lb_contraseña.setLayout(lb_contraseñaLayout);
        lb_contraseñaLayout.setHorizontalGroup(
            lb_contraseñaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lb_contraseñaLayout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addGroup(lb_contraseñaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lb_contraseñaLayout.createSequentialGroup()
                        .addGroup(lb_contraseñaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ch_remember)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_pass, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
                            .addComponent(txt_usuario, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
                            .addComponent(lb_usuario)
                            .addComponent(Lb_login)
                            .addComponent(bt_login, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bt_register, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(37, 37, 37))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lb_contraseñaLayout.createSequentialGroup()
                        .addComponent(lb_textoregistro, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))))
        );
        lb_contraseñaLayout.setVerticalGroup(
            lb_contraseñaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lb_contraseñaLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(Lb_login)
                .addGap(32, 32, 32)
                .addComponent(lb_usuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_pass, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ch_remember)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bt_login, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(lb_textoregistro)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bt_register, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_contraseña, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lb_contraseña, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(111, 111, 111)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 699, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_usuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_usuarioActionPerformed

    private void bt_registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_registerActionPerformed
        crearusuario cu = new crearusuario(); 
        cu.setVisible(true);
        cu.pack();
        cu.setLocationRelativeTo(null);
        this.dispose();
        
        
    }//GEN-LAST:event_bt_registerActionPerformed

    private void bt_registerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_registerMouseClicked
    }//GEN-LAST:event_bt_registerMouseClicked

    private void bt_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_loginActionPerformed
        
    }//GEN-LAST:event_bt_loginActionPerformed

    private void bt_loginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bt_loginMouseClicked
        String usu = txt_usuario.getText();
        String pass = new String(txt_pass.getPassword());
        
        String usurio = "Admin";
        String contraseña = "123456";
        
        if (usu.equals(usurio)&&pass.equals(contraseña)) {
            paneladmin pa = new paneladmin();
            pa.setVisible(true);
            pa.setLocationRelativeTo(null);
            dispose();
            return;
        }
        Connection con = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        boolean login = false;
        
        try {
            con = ConexionBD.getConnection();
            String query = "SELECT * FROM usuario WHERE usuario = ? AND clave = ?";
            st = con.prepareStatement(query);
            st.setString(1, usu);
            st.setString(2, pass);
            rs = st.executeQuery();
            if (rs.next()) {
                login = true;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al acceder", 
                    "Error de Datos",JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
                if (con != null) con.close();
            } catch (Exception e) {
            }
        }
        if (login) {
            iniciousuario in = new iniciousuario();
            in.setVisible(true);
            in.setLocationRelativeTo(null);
            dispose();
        } else {
            JOptionPane.showMessageDialog(null, "Usuario y/o contraseña incorrectos",
                    "Mensaje de Advertencia",JOptionPane.WARNING_MESSAGE);
        }
        
    }//GEN-LAST:event_bt_loginMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Lb_login;
    private javax.swing.JButton bt_login;
    private javax.swing.JButton bt_register;
    private javax.swing.JCheckBox ch_remember;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel lb_contraseña;
    private javax.swing.JPanel lb_derecha;
    private javax.swing.JLabel lb_icono;
    private javax.swing.JPanel lb_izquierda;
    private javax.swing.JLabel lb_textoregistro;
    private javax.swing.JLabel lb_titulo;
    private javax.swing.JLabel lb_usuario;
    private javax.swing.JPasswordField txt_pass;
    private javax.swing.JTextField txt_usuario;
    // End of variables declaration//GEN-END:variables
}
