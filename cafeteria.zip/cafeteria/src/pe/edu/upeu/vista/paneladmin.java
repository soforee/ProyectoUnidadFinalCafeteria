/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pe.edu.upeu.vista;

import java.awt.Image;
import java.awt.Toolkit;
import pe.edu.upeu.vista.catalogo.listarcatalogo;
import pe.edu.upeu.vista.pedido.listarPedido;
import pe.edu.upeu.vista.usuario.listarUsuario;

/**
 *
 * @author Doriann
 */
public class paneladmin extends javax.swing.JFrame {

    /**
     * Creates new form paneladmin
     */
    public paneladmin() {
        initComponents();
        setIconImage(getIconImage());
        
    }
    @Override
    public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("pe/edu/upeu/resources/img/logo.png"));
        return retValue; 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lb_logo = new javax.swing.JLabel();
        lb_titulo = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        lb_admin = new javax.swing.JLabel();
        btn_volver = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        lb_listaruser = new javax.swing.JLabel();
        lb_catalogoo = new javax.swing.JLabel();
        lb_pedido = new javax.swing.JLabel();
        btn_usuarios = new javax.swing.JButton();
        btn_calogo = new javax.swing.JButton();
        btn_pedidos = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(243, 233, 220));

        jPanel2.setBackground(new java.awt.Color(192, 133, 82));

        lb_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/logoinicio.png"))); // NOI18N

        lb_titulo.setFont(new java.awt.Font("Intro ", 1, 24)); // NOI18N
        lb_titulo.setForeground(new java.awt.Color(94, 48, 35));
        lb_titulo.setText("MIKUNAWASI");

        jPanel3.setBackground(new java.awt.Color(94, 48, 35));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 17, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jLabel4.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(137, 87, 55));
        jLabel4.setText("Copyright © 2025 MikunaWasi");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lb_titulo, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(lb_logo)
                                .addGap(31, 31, 31)))
                        .addGap(33, 33, 33)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(120, 120, 120)
                .addComponent(lb_logo)
                .addGap(18, 18, 18)
                .addComponent(lb_titulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addContainerGap())
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        lb_admin.setFont(new java.awt.Font("Intro ", 1, 24)); // NOI18N
        lb_admin.setForeground(new java.awt.Color(94, 48, 35));
        lb_admin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/admin.png"))); // NOI18N
        lb_admin.setText("MENÚ DE ADMINISTRADOR");

        btn_volver.setBackground(new java.awt.Color(94, 48, 35));
        btn_volver.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btn_volver.setText("VOLVER");
        btn_volver.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_volverMouseClicked(evt);
            }
        });

        lb_listaruser.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_listaruser.setForeground(new java.awt.Color(94, 48, 35));
        lb_listaruser.setText("USUARIOS");

        lb_catalogoo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_catalogoo.setForeground(new java.awt.Color(94, 48, 35));
        lb_catalogoo.setText("CATALOGO");

        lb_pedido.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_pedido.setForeground(new java.awt.Color(94, 48, 35));
        lb_pedido.setText("PEDIDOS");

        btn_usuarios.setBackground(new java.awt.Color(243, 233, 220));
        btn_usuarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/usuarios.png"))); // NOI18N
        btn_usuarios.setBorder(null);
        btn_usuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_usuariosActionPerformed(evt);
            }
        });

        btn_calogo.setBackground(new java.awt.Color(243, 233, 220));
        btn_calogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/catalogo_1.png"))); // NOI18N
        btn_calogo.setBorder(null);
        btn_calogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_calogoActionPerformed(evt);
            }
        });

        btn_pedidos.setBackground(new java.awt.Color(243, 233, 220));
        btn_pedidos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/pedir.png"))); // NOI18N
        btn_pedidos.setBorder(null);
        btn_pedidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pedidosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_volver)
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lb_admin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btn_usuarios)
                            .addComponent(btn_calogo)
                            .addComponent(btn_pedidos))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lb_catalogoo)
                            .addComponent(lb_listaruser)
                            .addComponent(lb_pedido))
                        .addGap(140, 140, 140))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(lb_admin, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(lb_listaruser))
                            .addComponent(btn_usuarios))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addComponent(lb_catalogoo))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(43, 43, 43)
                                .addComponent(btn_calogo)))
                        .addGap(62, 62, 62)
                        .addComponent(lb_pedido)
                        .addGap(16, 16, 16))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_pedidos)))
                .addGap(53, 53, 53)
                .addComponent(btn_volver)
                .addGap(15, 15, 15))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_volverMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_volverMouseClicked
        this.setVisible(false);
        login l = new login();
        l.setVisible(true);
        l.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_btn_volverMouseClicked

    private void btn_usuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_usuariosActionPerformed
        listarUsuario lu = new listarUsuario();
        panelUsuarios pa = new panelUsuarios();
        pa.mostrarPanel(lu);
        pa.setLocationRelativeTo(null);
        pa.setVisible(true);
    }//GEN-LAST:event_btn_usuariosActionPerformed

    private void btn_calogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_calogoActionPerformed
        listarcatalogo lc = new listarcatalogo();
        panelUsuarios pa = new panelUsuarios();
        pa.mostrarPanel(lc);
        pa.setLocationRelativeTo(null);
        pa.setVisible(true);
    }//GEN-LAST:event_btn_calogoActionPerformed

    private void btn_pedidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pedidosActionPerformed
        listarPedido lp = new listarPedido();
        panelUsuarios pa = new panelUsuarios();
        pa.mostrarPanel(lp);
        pa.setLocationRelativeTo(null);
        pa.setVisible(true);
    }//GEN-LAST:event_btn_pedidosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(paneladmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(paneladmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(paneladmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(paneladmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new paneladmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_calogo;
    private javax.swing.JButton btn_pedidos;
    private javax.swing.JButton btn_usuarios;
    private javax.swing.JButton btn_volver;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lb_admin;
    private javax.swing.JLabel lb_catalogoo;
    private javax.swing.JLabel lb_listaruser;
    private javax.swing.JLabel lb_logo;
    private javax.swing.JLabel lb_pedido;
    private javax.swing.JLabel lb_titulo;
    // End of variables declaration//GEN-END:variables
}
