
package pe.edu.upeu.vista;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import pe.edu.upeu.implementation.UsuarioDaoImpl;
import pe.edu.upeu.interfaces.iUsuarioDao;
import pe.edu.upeu.model.usuario;

public class crearusuario extends javax.swing.JFrame {

    public crearusuario() {
        initComponents();
        setIconImage(getIconImage());
    }
    
    @Override
    public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("pe/edu/upeu/resources/img/logo.png"));
        return retValue; 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lb_usuario = new javax.swing.JLabel();
        TXT_user = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txt_pass = new javax.swing.JPasswordField();
        lb_usuario3 = new javax.swing.JLabel();
        TXT_user3 = new javax.swing.JTextField();
        bt_login = new javax.swing.JButton();
        genero = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lb_icono = new javax.swing.JLabel();
        lb_titulo = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        Lb_register = new javax.swing.JLabel();
        lb_usuario1 = new javax.swing.JLabel();
        txt_usuario = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_contraseña = new javax.swing.JPasswordField();
        lb_usuario2 = new javax.swing.JLabel();
        txt_nombre = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        lb_usuario4 = new javax.swing.JLabel();
        txt_dni = new javax.swing.JTextField();
        txt_apellidos = new javax.swing.JTextField();
        bt_registrar = new javax.swing.JButton();
        lb_textoregistro = new javax.swing.JLabel();
        bt_loginusu = new javax.swing.JButton();
        lb_genero = new javax.swing.JLabel();
        btn_masculino = new javax.swing.JRadioButton();
        btn_femanino = new javax.swing.JRadioButton();

        lb_usuario.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        lb_usuario.setText("USUARIO");

        TXT_user.setBackground(new java.awt.Color(192, 133, 82));
        TXT_user.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        TXT_user.setForeground(new java.awt.Color(94, 48, 35));
        TXT_user.setBorder(null);
        TXT_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXT_userActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        jLabel2.setText("PASSWORD");

        txt_pass.setBackground(new java.awt.Color(192, 133, 82));
        txt_pass.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_pass.setForeground(new java.awt.Color(94, 48, 35));
        txt_pass.setBorder(null);

        lb_usuario3.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        lb_usuario3.setText("USUARIO");

        TXT_user3.setBackground(new java.awt.Color(192, 133, 82));
        TXT_user3.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        TXT_user3.setForeground(new java.awt.Color(94, 48, 35));
        TXT_user3.setBorder(null);
        TXT_user3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXT_user3ActionPerformed(evt);
            }
        });

        bt_login.setBackground(new java.awt.Color(94, 48, 35));
        bt_login.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        bt_login.setText("LOGIN");
        bt_login.setBorder(null);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(243, 233, 220));

        jPanel2.setBackground(new java.awt.Color(243, 233, 220));

        lb_icono.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/logoinicio.png"))); // NOI18N
        lb_icono.setText("jLabel2");

        lb_titulo.setFont(new java.awt.Font("Intro ", 0, 36)); // NOI18N
        lb_titulo.setForeground(new java.awt.Color(94, 48, 35));
        lb_titulo.setText("MikunaWasi");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/inicio.png"))); // NOI18N
        jLabel3.setText("jLabel3");

        jLabel4.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(137, 87, 55));
        jLabel4.setText("Copyright © 2025 MikunaWasi. Todos los derechos reservados.");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(158, 158, 158)
                .addComponent(lb_icono, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(64, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(188, 188, 188))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(lb_titulo)
                        .addGap(110, 110, 110))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(lb_icono)
                .addGap(18, 18, 18)
                .addComponent(lb_titulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(29, 29, 29))
        );

        jPanel3.setBackground(new java.awt.Color(137, 87, 55));
        jPanel3.setPreferredSize(new java.awt.Dimension(270, 450));

        Lb_register.setFont(new java.awt.Font("Intro ", 0, 24)); // NOI18N
        Lb_register.setText("REGISTRARSE");

        lb_usuario1.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        lb_usuario1.setText("USUARIO");

        txt_usuario.setBackground(new java.awt.Color(192, 133, 82));
        txt_usuario.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_usuario.setForeground(new java.awt.Color(94, 48, 35));
        txt_usuario.setBorder(null);
        txt_usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_usuarioActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        jLabel5.setText("PASSWORD");

        txt_contraseña.setBackground(new java.awt.Color(192, 133, 82));
        txt_contraseña.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_contraseña.setForeground(new java.awt.Color(94, 48, 35));
        txt_contraseña.setBorder(null);

        lb_usuario2.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        lb_usuario2.setText("NOMBRE");

        txt_nombre.setBackground(new java.awt.Color(192, 133, 82));
        txt_nombre.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_nombre.setForeground(new java.awt.Color(94, 48, 35));
        txt_nombre.setBorder(null);
        txt_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nombreActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        jLabel6.setText("APELLIDOS");

        lb_usuario4.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        lb_usuario4.setText("DNI");

        txt_dni.setBackground(new java.awt.Color(192, 133, 82));
        txt_dni.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_dni.setForeground(new java.awt.Color(94, 48, 35));
        txt_dni.setBorder(null);
        txt_dni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_dniActionPerformed(evt);
            }
        });

        txt_apellidos.setBackground(new java.awt.Color(192, 133, 82));
        txt_apellidos.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_apellidos.setForeground(new java.awt.Color(94, 48, 35));
        txt_apellidos.setBorder(null);
        txt_apellidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_apellidosActionPerformed(evt);
            }
        });

        bt_registrar.setBackground(new java.awt.Color(94, 48, 35));
        bt_registrar.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        bt_registrar.setText("REGISTRARSE");
        bt_registrar.setBorder(null);
        bt_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_registrarActionPerformed(evt);
            }
        });

        lb_textoregistro.setText("Si ya tienes cuenta");

        bt_loginusu.setBackground(new java.awt.Color(94, 48, 35));
        bt_loginusu.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        bt_loginusu.setText("LOGIN");
        bt_loginusu.setBorder(null);
        bt_loginusu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_loginusuActionPerformed(evt);
            }
        });

        lb_genero.setFont(new java.awt.Font("Intro ", 0, 12)); // NOI18N
        lb_genero.setText("GENERO");

        btn_masculino.setBackground(new java.awt.Color(192, 133, 82));
        genero.add(btn_masculino);
        btn_masculino.setText("M");

        btn_femanino.setBackground(new java.awt.Color(192, 133, 82));
        genero.add(btn_femanino);
        btn_femanino.setText("F");
        btn_femanino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_femaninoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lb_genero)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_masculino)
                        .addGap(18, 18, 18)
                        .addComponent(btn_femanino))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lb_textoregistro)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(bt_loginusu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(txt_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_contraseña)
                    .addComponent(txt_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lb_usuario1)
                    .addComponent(Lb_register)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_dni, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE)
                            .addComponent(lb_usuario4)
                            .addComponent(bt_registrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lb_usuario2))))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(Lb_register)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lb_usuario1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_usuario2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_usuario4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_dni, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_genero)
                    .addComponent(btn_masculino)
                    .addComponent(btn_femanino))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bt_registrar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_textoregistro)
                    .addComponent(bt_loginusu))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TXT_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXT_userActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXT_userActionPerformed

    private void txt_usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_usuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_usuarioActionPerformed

    private void txt_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nombreActionPerformed

    private void TXT_user3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXT_user3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXT_user3ActionPerformed

    private void txt_dniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_dniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_dniActionPerformed

    private void txt_apellidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_apellidosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_apellidosActionPerformed

    private void bt_loginusuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_loginusuActionPerformed
        login l = new login();
        l.setVisible(true);
        l.pack();
        l.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_bt_loginusuActionPerformed

    private void bt_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_registrarActionPerformed
        iUsuarioDao uDao = new UsuarioDaoImpl();
        usuario u = new usuario();
        if (txt_usuario.getText().trim().isEmpty()
                ||txt_contraseña.getText().trim().isEmpty()
                ||txt_nombre.getText().trim().isEmpty()
                ||txt_apellidos.getText().trim().isEmpty()
                ||txt_dni.getText().trim().isEmpty()
                ||!btn_masculino.isSelected()&&!btn_femanino.isSelected()) {
            JOptionPane.showMessageDialog(null, "Por favor, termine de registrarse",
                    "Mensaje Informativo",JOptionPane.WARNING_MESSAGE);
            return;
        }
        u.setUsuario(txt_usuario.getText().trim());
        u.setClave(txt_contraseña.getText().trim());
        u.setNombre(txt_nombre.getText().trim());
        u.setApellidos(txt_apellidos.getText().trim());
        u.setDni(txt_dni.getText().trim());
        String genero_select = btn_masculino.isSelected()?"M":"F";
        u.setGenero(genero_select);
        
        System.out.println("Usuario: "+u.getUsuario()+
                           "\nContraseña: "+u.getClave()+
                           "\nNombre: "+u.getNombre()+
                           "\nApellidos: "+u.getApellidos()+
                           "\nDNI: "+u.getDni()+
                           "\nGenero: "+u.getGenero());
        
        boolean result = uDao.insertar(u);
        if (result) {
            JOptionPane.showMessageDialog(null, "Registro satisfactorio",
                    "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Registro fallido",
                    "Mensaje Informativo",JOptionPane.ERROR_MESSAGE);
        }
        login l = new login();
        l.setVisible(true);
        l.pack();
        l.setLocationRelativeTo(null);
        this.dispose();
        
        
    }//GEN-LAST:event_bt_registrarActionPerformed

    private void btn_femaninoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_femaninoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_femaninoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(crearusuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(crearusuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(crearusuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(crearusuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new crearusuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Lb_register;
    private javax.swing.JTextField TXT_user;
    private javax.swing.JTextField TXT_user3;
    private javax.swing.JButton bt_login;
    private javax.swing.JButton bt_loginusu;
    private javax.swing.JButton bt_registrar;
    private javax.swing.JRadioButton btn_femanino;
    private javax.swing.JRadioButton btn_masculino;
    private javax.swing.ButtonGroup genero;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lb_genero;
    private javax.swing.JLabel lb_icono;
    private javax.swing.JLabel lb_textoregistro;
    private javax.swing.JLabel lb_titulo;
    private javax.swing.JLabel lb_usuario;
    private javax.swing.JLabel lb_usuario1;
    private javax.swing.JLabel lb_usuario2;
    private javax.swing.JLabel lb_usuario3;
    private javax.swing.JLabel lb_usuario4;
    private javax.swing.JTextField txt_apellidos;
    private javax.swing.JPasswordField txt_contraseña;
    private javax.swing.JTextField txt_dni;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JPasswordField txt_pass;
    private javax.swing.JTextField txt_usuario;
    // End of variables declaration//GEN-END:variables
}
