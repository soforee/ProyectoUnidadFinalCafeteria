/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pe.edu.upeu.vista.pedido;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import pe.edu.upeu.implementation.PedidoDaoImpl;
import pe.edu.upeu.interfaces.iPedidoDao;
import pe.edu.upeu.model.pedido;

/**
 *
 * @author Doriann
 */
public class agregarPedido extends javax.swing.JFrame {

    /**
     * Creates new form agregarPedido
     */
    public agregarPedido() {
        initComponents();
        setIconImage(getIconImage());
    }
    @Override
    public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("pe/edu/upeu/resources/img/logo.png"));
        return retValue; 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btn_agregar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();
        lb_mesa = new javax.swing.JLabel();
        cb_mesa = new javax.swing.JComboBox<>();
        lb_producto = new javax.swing.JLabel();
        cb_estado = new javax.swing.JComboBox<>();
        lb_fecha = new javax.swing.JLabel();
        txt_fecha = new javax.swing.JTextField();
        lb_total = new javax.swing.JLabel();
        txt_total = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(94, 48, 35));
        jPanel1.setPreferredSize(new java.awt.Dimension(588, 393));

        jPanel2.setBackground(new java.awt.Color(243, 233, 220));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Agregar Pedido", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18), new java.awt.Color(94, 48, 35))); // NOI18N
        jPanel2.setPreferredSize(new java.awt.Dimension(588, 393));

        btn_agregar.setBackground(new java.awt.Color(94, 48, 35));
        btn_agregar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_agregar.setText("REGISTER");
        btn_agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregarActionPerformed(evt);
            }
        });

        btn_cancelar.setBackground(new java.awt.Color(192, 133, 82));
        btn_cancelar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_cancelar.setForeground(new java.awt.Color(0, 0, 0));
        btn_cancelar.setText("CANCEL");
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });

        lb_mesa.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_mesa.setForeground(new java.awt.Color(192, 133, 82));
        lb_mesa.setText("MESA                                  :");

        cb_mesa.setBackground(new java.awt.Color(192, 133, 82));
        cb_mesa.setForeground(new java.awt.Color(0, 0, 0));
        cb_mesa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        cb_mesa.setBorder(null);
        cb_mesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_mesaActionPerformed(evt);
            }
        });

        lb_producto.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_producto.setForeground(new java.awt.Color(192, 133, 82));
        lb_producto.setText("ESTADO                              :");

        cb_estado.setBackground(new java.awt.Color(192, 133, 82));
        cb_estado.setForeground(new java.awt.Color(0, 0, 0));
        cb_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "EN PROCESO", "PAGADO", "CANCELADO" }));
        cb_estado.setBorder(null);

        lb_fecha.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_fecha.setForeground(new java.awt.Color(192, 133, 82));
        lb_fecha.setText("FECHA                                 :");

        txt_fecha.setBackground(new java.awt.Color(192, 133, 82));
        txt_fecha.setForeground(new java.awt.Color(0, 0, 0));
        txt_fecha.setBorder(null);

        lb_total.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_total.setForeground(new java.awt.Color(192, 133, 82));
        lb_total.setText("TOTAL                                 :");

        txt_total.setBackground(new java.awt.Color(192, 133, 82));
        txt_total.setForeground(new java.awt.Color(0, 0, 0));
        txt_total.setBorder(null);
        txt_total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_totalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btn_cancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_agregar))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lb_total)
                            .addComponent(lb_mesa))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_total, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cb_mesa, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lb_fecha)
                        .addGap(18, 18, 18)
                        .addComponent(txt_fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lb_producto)
                        .addGap(18, 18, 18)
                        .addComponent(cb_estado, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_mesa)
                    .addComponent(cb_mesa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_total)
                    .addComponent(txt_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_producto)
                    .addComponent(cb_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_fecha)
                    .addComponent(txt_fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 129, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_agregar)
                    .addComponent(btn_cancelar))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 576, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 383, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cb_mesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_mesaActionPerformed
        
    }//GEN-LAST:event_cb_mesaActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_btn_cancelarActionPerformed

    private void btn_agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarActionPerformed
        iPedidoDao pDao = new PedidoDaoImpl();
        pedido p = new pedido();
        if (cb_mesa.getSelectedItem()== null
                || txt_total.getText().trim().isEmpty()
                || cb_estado.getSelectedItem()==null
                || txt_fecha.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor termine de completar todos los campos",
                    "Mensaje Informativo",JOptionPane.WARNING_MESSAGE);
        }
        p.setMesa(cb_mesa.getSelectedIndex());
        p.setTotal(Double.parseDouble(txt_total.getText()));
        p.setEstado(cb_estado.getSelectedItem().toString());
        p.setFecha(txt_fecha.getText().trim());
        System.out.println("Mesa: "+p.getFecha()+
                           "\nTotal "+p.getTotal()+
                           "\nEstado: "+p.getEstado()+
                           "\nFecha "+p.getFecha());
        boolean result = pDao.insertar(p);
        if (result) {
            JOptionPane.showMessageDialog(null, "Registro de pedido satisfactorio",
                    "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Registro de pedido fallido",
                    "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
        }
        
    }//GEN-LAST:event_btn_agregarActionPerformed

    private void txt_totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_totalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_totalActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(agregarPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(agregarPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(agregarPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(agregarPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new agregarPedido().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_agregar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JComboBox<String> cb_estado;
    private javax.swing.JComboBox<String> cb_mesa;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lb_fecha;
    private javax.swing.JLabel lb_mesa;
    private javax.swing.JLabel lb_producto;
    private javax.swing.JLabel lb_total;
    private javax.swing.JTextField txt_fecha;
    private javax.swing.JTextField txt_total;
    // End of variables declaration//GEN-END:variables
}
