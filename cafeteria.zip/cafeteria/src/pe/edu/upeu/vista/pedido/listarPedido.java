
package pe.edu.upeu.vista.pedido;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import pe.edu.upeu.implementation.PedidoDaoImpl;
import pe.edu.upeu.interfaces.iPedidoDao;
import pe.edu.upeu.model.pedido;

public class listarPedido extends javax.swing.JPanel {
    iPedidoDao pDao = new PedidoDaoImpl();
    pedido p = new pedido();

    public listarPedido() {
        initComponents();
        listarPedido();
    }
    public void listarPedido(){
        List<pedido> lista = pDao.listar();
        DefaultTableModel tablemodel = (DefaultTableModel) tbl_pedidos.getModel();
        tablemodel.setNumRows(0);
        for (pedido p : lista) {
            Object[] rowData= {
                p.getIdpedido(),
                p.getMesa(),
                p.getTotal(),
                p.getEstado(),
                p.getFecha(),
            };
            tablemodel.addRow(rowData);
        }
        tbl_pedidos.setModel(tablemodel);
        JOptionPane.showMessageDialog(null, "Carga de pedido completo",
                "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_pedidos = new javax.swing.JTable();
        btn_actualizar = new javax.swing.JButton();
        btn_agregar = new javax.swing.JButton();
        btn_eliminar = new javax.swing.JButton();
        btn_editar = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(243, 233, 220));

        tbl_pedidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "idpedido", "mesa", "total", "estado", "fecha"
            }
        ));
        jScrollPane1.setViewportView(tbl_pedidos);

        btn_actualizar.setBackground(new java.awt.Color(243, 233, 220));
        btn_actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/actualizar.png"))); // NOI18N
        btn_actualizar.setBorder(null);
        btn_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_actualizarActionPerformed(evt);
            }
        });

        btn_agregar.setBackground(new java.awt.Color(243, 233, 220));
        btn_agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/agregar.png"))); // NOI18N
        btn_agregar.setBorder(null);
        btn_agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregarActionPerformed(evt);
            }
        });

        btn_eliminar.setBackground(new java.awt.Color(243, 233, 220));
        btn_eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/eliminar.png"))); // NOI18N
        btn_eliminar.setBorder(null);
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });

        btn_editar.setBackground(new java.awt.Color(243, 233, 220));
        btn_editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/editar.png"))); // NOI18N
        btn_editar.setBorder(null);
        btn_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 448, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btn_actualizar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_agregar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_eliminar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_editar)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_actualizar)
                    .addComponent(btn_agregar)
                    .addComponent(btn_eliminar)
                    .addComponent(btn_editar))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btn_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_actualizarActionPerformed
        listarPedido();
    }//GEN-LAST:event_btn_actualizarActionPerformed

    private void btn_agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarActionPerformed
        agregarPedido a = new agregarPedido();
        a.pack();
        a.setLocation(0,0);
        a.setLocationRelativeTo(null);
        a.setVisible(true);
        
    }//GEN-LAST:event_btn_agregarActionPerformed

    private void btn_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editarActionPerformed
        if (tbl_pedidos.getRowCount()>0) {
            if (tbl_pedidos.getSelectedRow() !=-1) {
                int idpedido = Integer.parseInt(tbl_pedidos.getValueAt(tbl_pedidos.getSelectedRow(), 0).toString());
                System.out.println("Id de pedido que se envia: "+idpedido);
                editarPedido ec = new editarPedido(idpedido);
                ec.setLocation(0,0);
                ec.setVisible(true);
                ec.setLocationRelativeTo(null);
            }
        }
    }//GEN-LAST:event_btn_editarActionPerformed

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        if (tbl_pedidos.getRowCount()>0) {
            if (tbl_pedidos.getSelectedRow() !=-1) {
                int idpedido = Integer.parseInt(tbl_pedidos.getValueAt(tbl_pedidos.getSelectedRow(), 0).toString());
                System.out.println("Id de pedido: "+idpedido);
                int rpta = JOptionPane.showConfirmDialog(null, "Estas por eliminar un pedido, ¿Seguro?");
                if (JOptionPane.OK_OPTION == rpta) {
                    p.setIdpedido(idpedido);
                    pDao.eliminar(p);
                    JOptionPane.showConfirmDialog(null, "Pedido eliminado",
                            "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showConfirmDialog(null, "Operacion cancelada",
                            "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }
    }//GEN-LAST:event_btn_eliminarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_actualizar;
    private javax.swing.JButton btn_agregar;
    private javax.swing.JButton btn_editar;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_pedidos;
    // End of variables declaration//GEN-END:variables
}
