
package pe.edu.upeu.vista.pedido;

import javax.swing.JOptionPane;
import pe.edu.upeu.implementation.PedidoDaoImpl;
import pe.edu.upeu.interfaces.iPedidoDao;
import pe.edu.upeu.model.pedido;

public class editarPedido extends javax.swing.JFrame {
    int idpedido;
    iPedidoDao pDao = new PedidoDaoImpl();

    public editarPedido(int idpedido) {
        this.idpedido = idpedido;
        System.out.println("Id de pedido que se recibe: "+idpedido);
        initComponents();
        buscarPedido(idpedido);
        
    }

    
    public void buscarPedido(int idpedido){
        pedido p = pDao.BuscarPorId(idpedido);
        try {
            cb_mesa_EDITAR.setSelectedItem(p.getMesa());
            txt_total.setText(String.valueOf(p.getTotal()));
            cb_estado.setSelectedItem(String.valueOf(p.getEstado()));
            txt_fecha_editar.setText(p.getFecha());
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showConfirmDialog(null, "Error al cargar los datos del pedido",
                    "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        btn_agregar_editar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();
        lb_mesa = new javax.swing.JLabel();
        cb_mesa_EDITAR = new javax.swing.JComboBox<>();
        lb_producto = new javax.swing.JLabel();
        lb_fecha = new javax.swing.JLabel();
        txt_fecha_editar = new javax.swing.JTextField();
        lb_estado = new javax.swing.JLabel();
        cb_estado = new javax.swing.JComboBox<>();
        txt_total = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(243, 233, 220));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Agregar Pedido", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18), new java.awt.Color(94, 48, 35))); // NOI18N
        jPanel2.setPreferredSize(new java.awt.Dimension(588, 393));

        btn_agregar_editar.setBackground(new java.awt.Color(94, 48, 35));
        btn_agregar_editar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_agregar_editar.setText("REGISTER");
        btn_agregar_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregar_editarActionPerformed(evt);
            }
        });

        btn_cancelar.setBackground(new java.awt.Color(192, 133, 82));
        btn_cancelar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_cancelar.setForeground(new java.awt.Color(0, 0, 0));
        btn_cancelar.setText("CANCEL");
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });

        lb_mesa.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_mesa.setForeground(new java.awt.Color(192, 133, 82));
        lb_mesa.setText("MESA                                  :");

        cb_mesa_EDITAR.setBackground(new java.awt.Color(192, 133, 82));
        cb_mesa_EDITAR.setForeground(new java.awt.Color(0, 0, 0));
        cb_mesa_EDITAR.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        cb_mesa_EDITAR.setBorder(null);
        cb_mesa_EDITAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_mesa_EDITARActionPerformed(evt);
            }
        });

        lb_producto.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_producto.setForeground(new java.awt.Color(192, 133, 82));
        lb_producto.setText("TOTAL                                 :");

        lb_fecha.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_fecha.setForeground(new java.awt.Color(192, 133, 82));
        lb_fecha.setText("FECHA                                 :");

        txt_fecha_editar.setBackground(new java.awt.Color(192, 133, 82));
        txt_fecha_editar.setForeground(new java.awt.Color(0, 0, 0));
        txt_fecha_editar.setBorder(null);

        lb_estado.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_estado.setForeground(new java.awt.Color(192, 133, 82));
        lb_estado.setText("ESTADO                              :");

        cb_estado.setBackground(new java.awt.Color(192, 133, 82));
        cb_estado.setForeground(new java.awt.Color(0, 0, 0));
        cb_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CANCELADO", "PAGADO", "EN PROCESO" }));
        cb_estado.setBorder(null);

        txt_total.setBackground(new java.awt.Color(192, 133, 82));
        txt_total.setForeground(new java.awt.Color(0, 0, 0));
        txt_total.setBorder(null);
        txt_total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_totalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btn_cancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_agregar_editar))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lb_fecha)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lb_mesa)
                        .addComponent(lb_producto)
                        .addComponent(lb_estado)))
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_total, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(cb_mesa_EDITAR, 0, 232, Short.MAX_VALUE)
                        .addComponent(txt_fecha_editar)
                        .addComponent(cb_estado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(51, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_mesa)
                    .addComponent(cb_mesa_EDITAR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_producto)
                    .addComponent(txt_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_estado)
                    .addComponent(cb_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_fecha)
                    .addComponent(txt_fecha_editar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 112, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_agregar_editar)
                    .addComponent(btn_cancelar))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 576, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 381, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_agregar_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregar_editarActionPerformed
        iPedidoDao pDao = new PedidoDaoImpl();
        pedido p = new pedido();
        if (cb_mesa_EDITAR.getSelectedItem()== null
            || txt_total.getText().trim().isEmpty()
            || cb_estado.getSelectedItem() == null
            || txt_fecha_editar.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor termine de completar todos los campos",
                "Mensaje Informativo",JOptionPane.WARNING_MESSAGE);
        }
        p.setMesa(cb_mesa_EDITAR.getSelectedIndex());
        p.setTotal(Double.parseDouble(txt_total.getText()));
        p.setEstado(cb_estado.getSelectedItem().toString());
        p.setFecha(txt_fecha_editar.getText().trim());
        p.setIdpedido(idpedido);
        System.out.println("Mesa: "+p.getFecha()+
                    "\ntotal: "+p.getTotal()+
                    "\nEstado "+p.getEstado()+
                    "\nFecha "+p.getFecha());
        boolean result = pDao.editar(p);
        if (result) {
            JOptionPane.showMessageDialog(null, "Registro de pedido satisfactorio",
                "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Registro de pedido fallido",
                "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
        }

    }//GEN-LAST:event_btn_agregar_editarActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_btn_cancelarActionPerformed

    private void cb_mesa_EDITARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_mesa_EDITARActionPerformed

    }//GEN-LAST:event_cb_mesa_EDITARActionPerformed

    private void txt_totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_totalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_totalActionPerformed
//
//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(editarPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(editarPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(editarPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(editarPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new editarPedido().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_agregar_editar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JComboBox<String> cb_estado;
    private javax.swing.JComboBox<String> cb_mesa_EDITAR;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lb_estado;
    private javax.swing.JLabel lb_fecha;
    private javax.swing.JLabel lb_mesa;
    private javax.swing.JLabel lb_producto;
    private javax.swing.JTextField txt_fecha_editar;
    private javax.swing.JTextField txt_total;
    // End of variables declaration//GEN-END:variables
}
