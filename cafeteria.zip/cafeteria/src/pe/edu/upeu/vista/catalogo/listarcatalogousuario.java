/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package pe.edu.upeu.vista.catalogo;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import pe.edu.upeu.implementation.CatalogoDaoImpl;
import pe.edu.upeu.interfaces.iCatalogoDao;
import pe.edu.upeu.model.catalogo;

/**
 *
 * @author Doriann
 */
public class listarcatalogousuario extends javax.swing.JPanel {

    iCatalogoDao CaDao = new CatalogoDaoImpl();
    
    
    public listarcatalogousuario() {
        initComponents();
        listarcatalogousuario();
        
    }
    
    public void listarcatalogousuario(){
        List<catalogo> listar = CaDao.listar();
        DefaultTableModel tablemodel = (DefaultTableModel) tbl_catalogousuario.getModel();
        tablemodel.setNumRows(0);
        for (catalogo ca : listar) {
            Object[] rowData = {
                ca.getIdproducto(),
                ca.getNameProduct(),
                ca.getTipo(),
                ca.getPrecio(),
            };
            tablemodel.addRow(rowData);
        }
        tbl_catalogousuario.setModel(tablemodel);
        JOptionPane.showMessageDialog(null, "Carga de catalogo completa",
                "Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_catalogousuario = new javax.swing.JTable();

        jPanel1.setBackground(new java.awt.Color(243, 233, 220));

        tbl_catalogousuario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "idproducto", "nameproducto", "tipo", "precio"
            }
        ));
        jScrollPane1.setViewportView(tbl_catalogousuario);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 472, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(75, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_catalogousuario;
    // End of variables declaration//GEN-END:variables
}
