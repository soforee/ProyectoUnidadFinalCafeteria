/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package pe.edu.upeu.vista.catalogo;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import pe.edu.upeu.implementation.CatalogoDaoImpl;
import pe.edu.upeu.interfaces.iCatalogoDao;
import pe.edu.upeu.model.catalogo;

/**
 *
 * @author Doriann
 */
public class listarcatalogo extends javax.swing.JPanel {

    iCatalogoDao cDao = new CatalogoDaoImpl();
    catalogo c = new catalogo();

    public listarcatalogo() {
        initComponents();
        listarCatalogo();
    }
    public void listarCatalogo(){
        List<catalogo> lista = cDao.listar();
        DefaultTableModel tablemodel = (DefaultTableModel) tbl_catalogo.getModel();
        tablemodel.setNumRows(0);
        for (catalogo c : lista) {
            Object[] rowData={
                c.getIdproducto(),
                c.getNameProduct(),
                c.getTipo(),
                c.getPrecio(),
            };
            tablemodel.addRow(rowData);
        }
        tbl_catalogo.setModel(tablemodel);
        JOptionPane.showMessageDialog(null, "Carga del catalogo completa",
                "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_catalogo = new javax.swing.JTable();
        btn_actualizar = new javax.swing.JButton();
        btn_agregar = new javax.swing.JButton();
        btn_eliminar = new javax.swing.JButton();
        btn_editar = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(243, 233, 220));

        tbl_catalogo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "idproducto", "nameProduct", "tipo", "precio"
            }
        ));
        jScrollPane1.setViewportView(tbl_catalogo);

        btn_actualizar.setBackground(new java.awt.Color(243, 233, 220));
        btn_actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/actualizar.png"))); // NOI18N
        btn_actualizar.setBorder(null);
        btn_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_actualizarActionPerformed(evt);
            }
        });

        btn_agregar.setBackground(new java.awt.Color(243, 233, 220));
        btn_agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/agregar.png"))); // NOI18N
        btn_agregar.setBorder(null);
        btn_agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregarActionPerformed(evt);
            }
        });

        btn_eliminar.setBackground(new java.awt.Color(243, 233, 220));
        btn_eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/eliminar.png"))); // NOI18N
        btn_eliminar.setBorder(null);
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });

        btn_editar.setBackground(new java.awt.Color(243, 233, 220));
        btn_editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/editar.png"))); // NOI18N
        btn_editar.setBorder(null);
        btn_editar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_editarMouseClicked(evt);
            }
        });
        btn_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 448, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btn_actualizar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_agregar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_eliminar)
                        .addGap(5, 5, 5)
                        .addComponent(btn_editar)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_actualizar)
                    .addComponent(btn_agregar)
                    .addComponent(btn_eliminar)
                    .addComponent(btn_editar))
                .addContainerGap(71, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btn_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_actualizarActionPerformed
        listarCatalogo();
    }//GEN-LAST:event_btn_actualizarActionPerformed

    private void btn_agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarActionPerformed
        agregarCatalogo a = new agregarCatalogo();
        a.pack();
        a.setLocation(0,0);
        a.setLocationRelativeTo(null);
        a.setVisible(true);
        
    }//GEN-LAST:event_btn_agregarActionPerformed

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        if (tbl_catalogo.getRowCount()>0) {
            if (tbl_catalogo.getSelectedRow() !=-1) {
                int idcatalogo = Integer.parseInt(tbl_catalogo.getValueAt(tbl_catalogo.getSelectedRow(), 0).toString());
                System.out.println("Id Catalogo: "+idcatalogo);
                int rpta = JOptionPane.showConfirmDialog(null, "Estar por eliminar un producto del catalogo, ¿Seguro?");
                if (JOptionPane.OK_OPTION == rpta) {
                    c.setIdproducto(idcatalogo);
                    cDao.eliminar(c);
                    JOptionPane.showMessageDialog(null, "Producto del catalogo eliminado",
                            "Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Operacion cancelada",
                            "Mensasje Informativo",JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_editarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_editarMouseClicked

    }//GEN-LAST:event_btn_editarMouseClicked

    private void btn_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editarActionPerformed
        if (tbl_catalogo.getRowCount()>0) {
            if (tbl_catalogo.getSelectedRow() !=-1) {
                int idcatalogo = Integer.parseInt(tbl_catalogo.getValueAt(tbl_catalogo.getSelectedRow(), 0).toString());
                System.out.println("Idcatalogo que se recibe: "+idcatalogo);
                editarCatalogo ec = new editarCatalogo(idcatalogo);
                ec.setLocation(0,0);
                ec.setVisible(true);
                ec.setLocationRelativeTo(null);
            }
        }

    }//GEN-LAST:event_btn_editarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_actualizar;
    private javax.swing.JButton btn_agregar;
    private javax.swing.JButton btn_editar;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_catalogo;
    // End of variables declaration//GEN-END:variables
}
