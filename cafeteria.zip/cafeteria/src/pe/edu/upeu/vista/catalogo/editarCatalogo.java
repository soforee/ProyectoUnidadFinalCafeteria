
package pe.edu.upeu.vista.catalogo;

import javax.swing.JOptionPane;
import pe.edu.upeu.implementation.CatalogoDaoImpl;
import pe.edu.upeu.interfaces.iCatalogoDao;
import pe.edu.upeu.model.catalogo;

public class editarCatalogo extends javax.swing.JFrame {
    int idcatalogo;
    iCatalogoDao cDao = new CatalogoDaoImpl();

    public editarCatalogo(int idcatalogo) {
        this.idcatalogo = idcatalogo;
        System.out.println("Id de catalogo que se recibe: "+idcatalogo);
        initComponents();
        buscarCatalogo(idcatalogo);
    }
    public void buscarCatalogo(int idcatalogo) {
        catalogo c = cDao.BuscarPorId(idcatalogo);
        try {
            txt_nameproduct_editar.setText(c.getNameProduct());
            cb_tipo_editar.setSelectedItem(c.getTipo());
            txt_precio_editar.setText(String.valueOf(c.getPrecio()));
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los datos del producto",
                    "Mensaje Informativo",JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btn_agregar_editar = new javax.swing.JButton();
        btn_cancel_editar = new javax.swing.JButton();
        lb_nameProducto = new javax.swing.JLabel();
        lb_tipo = new javax.swing.JLabel();
        lb_precio = new javax.swing.JLabel();
        txt_nameproduct_editar = new javax.swing.JTextField();
        cb_tipo_editar = new javax.swing.JComboBox<>();
        txt_precio_editar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(94, 48, 35));

        jPanel2.setBackground(new java.awt.Color(243, 233, 220));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Agregar Producto al Catalogo", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18), new java.awt.Color(94, 48, 35))); // NOI18N

        btn_agregar_editar.setBackground(new java.awt.Color(94, 48, 35));
        btn_agregar_editar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_agregar_editar.setText("REGISTER");
        btn_agregar_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregar_editarActionPerformed(evt);
            }
        });

        btn_cancel_editar.setBackground(new java.awt.Color(192, 133, 82));
        btn_cancel_editar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_cancel_editar.setText("CANCEL");
        btn_cancel_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancel_editarActionPerformed(evt);
            }
        });

        lb_nameProducto.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_nameProducto.setForeground(new java.awt.Color(137, 87, 55));
        lb_nameProducto.setText("NOMBRE DEL PRODUCTO    :");

        lb_tipo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_tipo.setForeground(new java.awt.Color(137, 87, 55));
        lb_tipo.setText("TIPO                                      :");

        lb_precio.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lb_precio.setForeground(new java.awt.Color(137, 87, 55));
        lb_precio.setText("PRECIO                                  :");

        txt_nameproduct_editar.setBackground(new java.awt.Color(137, 87, 55));
        txt_nameproduct_editar.setForeground(new java.awt.Color(0, 0, 0));
        txt_nameproduct_editar.setBorder(null);
        txt_nameproduct_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nameproduct_editarActionPerformed(evt);
            }
        });

        cb_tipo_editar.setBackground(new java.awt.Color(137, 87, 55));
        cb_tipo_editar.setForeground(new java.awt.Color(0, 0, 0));
        cb_tipo_editar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Bebida Natrural", "Bebida Gasificada", "Entrada", "Plato Principal", "Postre" }));
        cb_tipo_editar.setBorder(null);

        txt_precio_editar.setBackground(new java.awt.Color(137, 87, 55));
        txt_precio_editar.setForeground(new java.awt.Color(0, 0, 0));
        txt_precio_editar.setBorder(null);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_cancel_editar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_agregar_editar)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lb_precio)
                        .addGap(18, 18, 18)
                        .addComponent(txt_precio_editar))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lb_tipo)
                        .addGap(18, 18, 18)
                        .addComponent(cb_tipo_editar, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lb_nameProducto)
                        .addGap(18, 18, 18)
                        .addComponent(txt_nameproduct_editar, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(37, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(95, 95, 95)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_nameProducto)
                    .addComponent(txt_nameproduct_editar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_tipo)
                    .addComponent(cb_tipo_editar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_precio)
                    .addComponent(txt_precio_editar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 103, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_agregar_editar)
                    .addComponent(btn_cancel_editar))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_agregar_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregar_editarActionPerformed
        iCatalogoDao cDao = new CatalogoDaoImpl();
        catalogo c = new catalogo();
        if (txt_nameproduct_editar.getText().trim().isEmpty()
            || cb_tipo_editar.getSelectedItem()== null
            || txt_precio_editar.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor completa todos los campos",
                "Mensaje informativo",JOptionPane.WARNING_MESSAGE);
        }
        c.setNameProduct(txt_nameproduct_editar.getText().trim());
        c.setTipo(cb_tipo_editar.getSelectedItem().toString());
        c.setPrecio(Double.parseDouble(txt_precio_editar.getText().trim()));
        c.setIdproducto(idcatalogo);

        System.out.println("Name Producto: "+c.getNameProduct()+
            "\nTipo: "+c.getTipo()+
            "\nPrecio: "+c.getPrecio());
        boolean result = cDao.editar(c);
        if (result) {
            JOptionPane.showMessageDialog(null, "Registro de producto satisfactorio",
                "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Registro de producto fallido",
                "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btn_agregar_editarActionPerformed

    private void btn_cancel_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancel_editarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_btn_cancel_editarActionPerformed

    private void txt_nameproduct_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nameproduct_editarActionPerformed

    }//GEN-LAST:event_txt_nameproduct_editarActionPerformed
//
//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(editarCatalog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(editarCatalog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(editarCatalog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(editarCatalog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new editarCatalog().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_agregar_editar;
    private javax.swing.JButton btn_cancel_editar;
    private javax.swing.JComboBox<String> cb_tipo_editar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lb_nameProducto;
    private javax.swing.JLabel lb_precio;
    private javax.swing.JLabel lb_tipo;
    private javax.swing.JTextField txt_nameproduct_editar;
    private javax.swing.JTextField txt_precio_editar;
    // End of variables declaration//GEN-END:variables
}
