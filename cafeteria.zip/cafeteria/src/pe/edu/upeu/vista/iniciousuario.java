/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pe.edu.upeu.vista;

import java.awt.Image;
import java.awt.Toolkit;
import pe.edu.upeu.vista.catalogo.listarcatalogo;
import pe.edu.upeu.vista.catalogo.listarcatalogousuario;
import pe.edu.upeu.vista.pedido.agregarPedido;
import pe.edu.upeu.vista.usuario.editarUsuario;


/**
 *
 * @author Doriann
 */
public class iniciousuario extends javax.swing.JFrame {

    /**
     * Creates new form iniciousuario
     */
    public iniciousuario() {
        initComponents();
        setIconImage(getIconImage());
    }

    @Override
    public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("pe/edu/upeu/resources/img/logo.png"));
        return retValue; 
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        lb_logo = new javax.swing.JLabel();
        lb_titulo = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lb_titulousuario = new javax.swing.JLabel();
        volver = new javax.swing.JButton();
        js_separador = new javax.swing.JSeparator();
        panel_contenedor = new javax.swing.JPanel();
        btn_catalogo = new javax.swing.JButton();
        lb_catalog1 = new javax.swing.JLabel();
        btn_pedido = new javax.swing.JButton();
        lb_pedido = new javax.swing.JLabel();
        btn_editar = new javax.swing.JButton();
        lb_editar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(94, 48, 35));

        jPanel1.setBackground(new java.awt.Color(192, 133, 82));

        lb_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/logoinicio.png"))); // NOI18N

        lb_titulo.setFont(new java.awt.Font("Intro ", 0, 36)); // NOI18N
        lb_titulo.setForeground(new java.awt.Color(94, 48, 35));
        lb_titulo.setText("MikunaWasi");

        jLabel4.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(137, 87, 55));
        jLabel4.setText("Copyright © 2025 MikunaWasi");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel4)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lb_logo)
                        .addGap(87, 87, 87))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lb_titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(107, 107, 107)
                .addComponent(lb_logo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lb_titulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 149, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(243, 233, 220));

        lb_titulousuario.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        lb_titulousuario.setForeground(new java.awt.Color(0, 0, 0));
        lb_titulousuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/usuario.png"))); // NOI18N
        lb_titulousuario.setText("MENÚ DEL USUARIO ");

        volver.setBackground(new java.awt.Color(94, 48, 35));
        volver.setText("VOLVER");
        volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volverActionPerformed(evt);
            }
        });

        panel_contenedor.setBackground(new java.awt.Color(243, 233, 220));

        btn_catalogo.setBackground(new java.awt.Color(243, 233, 220));
        btn_catalogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/catalogo_1.png"))); // NOI18N
        btn_catalogo.setBorder(null);
        btn_catalogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_catalogoActionPerformed(evt);
            }
        });

        lb_catalog1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_catalog1.setForeground(new java.awt.Color(137, 87, 55));
        lb_catalog1.setText("CATALOGO");
        lb_catalog1.setAlignmentX(0.5F);

        btn_pedido.setBackground(new java.awt.Color(243, 233, 220));
        btn_pedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/pedir.png"))); // NOI18N
        btn_pedido.setBorder(null);
        btn_pedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pedidoActionPerformed(evt);
            }
        });

        lb_pedido.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_pedido.setForeground(new java.awt.Color(137, 87, 55));
        lb_pedido.setText("PEDIDO");
        lb_pedido.setAlignmentX(0.5F);

        btn_editar.setBackground(new java.awt.Color(243, 233, 220));
        btn_editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/editar_1.png"))); // NOI18N
        btn_editar.setToolTipText("");
        btn_editar.setBorder(null);
        btn_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editarActionPerformed(evt);
            }
        });

        lb_editar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_editar.setForeground(new java.awt.Color(137, 87, 55));
        lb_editar.setText("EDITAR PERFIL");
        lb_editar.setAlignmentX(0.5F);

        javax.swing.GroupLayout panel_contenedorLayout = new javax.swing.GroupLayout(panel_contenedor);
        panel_contenedor.setLayout(panel_contenedorLayout);
        panel_contenedorLayout.setHorizontalGroup(
            panel_contenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_contenedorLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panel_contenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel_contenedorLayout.createSequentialGroup()
                        .addComponent(btn_pedido)
                        .addGap(18, 18, 18)
                        .addComponent(lb_pedido))
                    .addGroup(panel_contenedorLayout.createSequentialGroup()
                        .addComponent(btn_catalogo)
                        .addGap(18, 18, 18)
                        .addComponent(lb_catalog1))
                    .addGroup(panel_contenedorLayout.createSequentialGroup()
                        .addComponent(btn_editar)
                        .addGap(18, 18, 18)
                        .addComponent(lb_editar)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_contenedorLayout.setVerticalGroup(
            panel_contenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_contenedorLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lb_catalog1)
                .addGap(48, 48, 48)
                .addComponent(lb_pedido)
                .addGap(45, 45, 45)
                .addComponent(lb_editar)
                .addGap(80, 80, 80))
            .addGroup(panel_contenedorLayout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(btn_catalogo)
                .addGap(18, 18, 18)
                .addComponent(btn_pedido)
                .addGap(18, 18, 18)
                .addComponent(btn_editar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(panel_contenedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 64, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(volver)
                                .addGap(22, 22, 22))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(js_separador)
                                    .addComponent(lb_titulousuario))
                                .addGap(56, 56, 56))))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(lb_titulousuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(js_separador, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel_contenedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(volver)
                .addGap(15, 15, 15))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volverActionPerformed
        login l = new login();
        l.setVisible(true);
        l.setLocationRelativeTo(null);
        dispose();
    }//GEN-LAST:event_volverActionPerformed

    private void btn_catalogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_catalogoActionPerformed
        listarcatalogousuario lc = new listarcatalogousuario();
        panelCatalogo i = new panelCatalogo();
        i.mostrarPanel(lc);
        i.setVisible(true);
        i.setLocationRelativeTo(null);
        
    }//GEN-LAST:event_btn_catalogoActionPerformed

    private void btn_pedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pedidoActionPerformed
        agregarPedido ap = new agregarPedido();
        ap.setVisible(true);
        ap.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_pedidoActionPerformed

    private void btn_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editarActionPerformed
        editarUsuario eu = new editarUsuario(WIDTH);
        eu.setVisible(true);
        eu.setLocationRelativeTo(null);
    }//GEN-LAST:event_btn_editarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(iniciousuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(iniciousuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(iniciousuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(iniciousuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new iniciousuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_catalogo;
    private javax.swing.JButton btn_editar;
    private javax.swing.JButton btn_pedido;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSeparator js_separador;
    private javax.swing.JLabel lb_catalog1;
    private javax.swing.JLabel lb_editar;
    private javax.swing.JLabel lb_logo;
    private javax.swing.JLabel lb_pedido;
    private javax.swing.JLabel lb_titulo;
    private javax.swing.JLabel lb_titulousuario;
    private javax.swing.JPanel panel_contenedor;
    private javax.swing.JButton volver;
    // End of variables declaration//GEN-END:variables
}
