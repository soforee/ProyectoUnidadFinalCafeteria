
package pe.edu.upeu.vista.usuario;


import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import pe.edu.upeu.implementation.UsuarioDaoImpl;
import pe.edu.upeu.interfaces.iUsuarioDao;
import pe.edu.upeu.model.usuario;

public class listarUsuario extends javax.swing.JPanel {
    iUsuarioDao uDao = new UsuarioDaoImpl();
    usuario u = new usuario();

    public listarUsuario() {
        initComponents();
        listarUsuario();
        
    }
    public void listarUsuario(){
        List<usuario> lista = uDao.listar();
        DefaultTableModel tablemodel = (DefaultTableModel) tbl_usuarios.getModel();
        tablemodel.setNumRows(0);
        for (usuario u : lista) {
            String genero;
            if (u.getGenero().equalsIgnoreCase("M")) {
                genero = "Masculino";
            } else {
                genero = "Femenino";
            }
            Object[] rowData={
                u.getIdusuario(),
                u.getUsuario(),
                u.getClave(),
                u.getNombre(),
                u.getApellidos(),
                u.getDni(),
                genero
            };
            tablemodel.addRow(rowData);
        }
        tbl_usuarios.setModel(tablemodel);
        JOptionPane.showMessageDialog(null, "Carga de usuario completa",
                "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
    }



    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_usuarios = new javax.swing.JTable();
        btn_actualizar = new javax.swing.JButton();
        btn_agregar = new javax.swing.JButton();
        btn_eliminar = new javax.swing.JButton();
        btn_editar = new javax.swing.JButton();

        setBackground(new java.awt.Color(243, 233, 220));

        tbl_usuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Usuario", "Usuario", "Clave", "Nombre", "Apellidos", "DNI", "Genero"
            }
        ));
        jScrollPane2.setViewportView(tbl_usuarios);

        btn_actualizar.setBackground(new java.awt.Color(243, 233, 220));
        btn_actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/actualizar.png"))); // NOI18N
        btn_actualizar.setBorder(null);
        btn_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_actualizarActionPerformed(evt);
            }
        });

        btn_agregar.setBackground(new java.awt.Color(243, 233, 220));
        btn_agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/agregar.png"))); // NOI18N
        btn_agregar.setBorder(null);
        btn_agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregarActionPerformed(evt);
            }
        });

        btn_eliminar.setBackground(new java.awt.Color(243, 233, 220));
        btn_eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/eliminar.png"))); // NOI18N
        btn_eliminar.setBorder(null);
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });

        btn_editar.setBackground(new java.awt.Color(243, 233, 220));
        btn_editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pe/edu/upeu/resources/img/editar.png"))); // NOI18N
        btn_editar.setBorder(null);
        btn_editar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_editarMouseClicked(evt);
            }
        });
        btn_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 448, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btn_actualizar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_agregar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_eliminar)
                        .addGap(5, 5, 5)
                        .addComponent(btn_editar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_actualizar)
                    .addComponent(btn_agregar)
                    .addComponent(btn_eliminar)
                    .addComponent(btn_editar))
                .addContainerGap(49, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btn_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_actualizarActionPerformed
        listarUsuario();
    }//GEN-LAST:event_btn_actualizarActionPerformed

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        if (tbl_usuarios.getRowCount()>0) {
            if (tbl_usuarios.getSelectedRow() !=-1) {
                int idUsuarios = Integer.parseInt(tbl_usuarios.getValueAt(tbl_usuarios.getSelectedRow(), 0).toString());
                System.out.println("Id Usuario: "+idUsuarios);
                int rpta = JOptionPane.showConfirmDialog(null, "Estas por eliminar un usurio, ¿Seguro?");
                if (JOptionPane.OK_OPTION == rpta) {
                    u.setIdusuario(idUsuarios);
                    uDao.eliminar(u);
                    JOptionPane.showMessageDialog(null, "Usuario eliminado",
                            "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Operación cancelada",
                            "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarActionPerformed
        agregarUsuario a = new agregarUsuario();
        a.pack();
        a.setLocation(0,0);
        a.setLocationRelativeTo(null);
        a.setVisible(true);
    }//GEN-LAST:event_btn_agregarActionPerformed

    private void btn_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editarActionPerformed
        if (tbl_usuarios.getRowCount() >0) {
            if (tbl_usuarios.getSelectedRow() !=-1) {
                int idUsuario = Integer.parseInt(tbl_usuarios.getValueAt(tbl_usuarios.getSelectedRow(),0).toString());
                System.out.println("idUsuario que se envia: "+idUsuario);
                editarUsuario eu = new editarUsuario(idUsuario);
                eu.setLocation(0,0);
                eu.setVisible(true);
                eu.setLocationRelativeTo(null);
            }
        }
        
    }//GEN-LAST:event_btn_editarActionPerformed

    private void btn_editarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_editarMouseClicked
    }//GEN-LAST:event_btn_editarMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_actualizar;
    private javax.swing.JButton btn_agregar;
    private javax.swing.JButton btn_editar;
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tbl_usuarios;
    // End of variables declaration//GEN-END:variables
}
