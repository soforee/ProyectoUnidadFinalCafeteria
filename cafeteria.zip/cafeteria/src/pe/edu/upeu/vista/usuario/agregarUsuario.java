/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pe.edu.upeu.vista.usuario;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import pe.edu.upeu.implementation.UsuarioDaoImpl;
import pe.edu.upeu.interfaces.iUsuarioDao;
import pe.edu.upeu.model.usuario;

/**
 *
 * @author Doriann
 */
public class agregarUsuario extends javax.swing.JFrame {

    public agregarUsuario() {
        initComponents();
        setIconImage(getIconImage());
        
    }
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("pe/edu/upeu/resources/img/logo.png"));
        return retValue;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        genero = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        lb_usuario = new javax.swing.JLabel();
        lb_contraseña = new javax.swing.JLabel();
        lb_nombre = new javax.swing.JLabel();
        lb_apellidos = new javax.swing.JLabel();
        lb_dni = new javax.swing.JLabel();
        lb_genero = new javax.swing.JLabel();
        btn_registrar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();
        txt_usuario = new javax.swing.JTextField();
        txt_nombre = new javax.swing.JTextField();
        txt_apellidos = new javax.swing.JTextField();
        txt_dni = new javax.swing.JTextField();
        txt_password = new javax.swing.JPasswordField();
        rb_masculino = new javax.swing.JRadioButton();
        rb_femenino = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(243, 233, 220));

        jPanel2.setBackground(new java.awt.Color(94, 48, 35));

        jPanel1.setBackground(new java.awt.Color(243, 233, 220));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Agregar Usuario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18), new java.awt.Color(94, 48, 35))); // NOI18N
        jPanel1.setForeground(new java.awt.Color(243, 233, 220));

        lb_usuario.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_usuario.setForeground(new java.awt.Color(137, 87, 55));
        lb_usuario.setText("USUARIO            : ");

        lb_contraseña.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_contraseña.setForeground(new java.awt.Color(137, 87, 55));
        lb_contraseña.setText("CONTRASEÑA    :");

        lb_nombre.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_nombre.setForeground(new java.awt.Color(137, 87, 55));
        lb_nombre.setText("NOMBRE            :");

        lb_apellidos.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_apellidos.setForeground(new java.awt.Color(137, 87, 55));
        lb_apellidos.setText("APELLIDO           :");

        lb_dni.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_dni.setForeground(new java.awt.Color(137, 87, 55));
        lb_dni.setText("DNI                      :");

        lb_genero.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_genero.setForeground(new java.awt.Color(137, 87, 55));
        lb_genero.setText("GENERO             :");

        btn_registrar.setBackground(new java.awt.Color(94, 48, 35));
        btn_registrar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_registrar.setText("REGISTER");
        btn_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarActionPerformed(evt);
            }
        });

        btn_cancelar.setBackground(new java.awt.Color(192, 133, 82));
        btn_cancelar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_cancelar.setForeground(new java.awt.Color(0, 0, 0));
        btn_cancelar.setText("CANCEL");
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });

        txt_usuario.setBackground(new java.awt.Color(192, 133, 82));
        txt_usuario.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_usuario.setForeground(new java.awt.Color(0, 0, 0));
        txt_usuario.setBorder(null);

        txt_nombre.setBackground(new java.awt.Color(192, 133, 82));
        txt_nombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_nombre.setForeground(new java.awt.Color(0, 0, 0));
        txt_nombre.setBorder(null);

        txt_apellidos.setBackground(new java.awt.Color(192, 133, 82));
        txt_apellidos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_apellidos.setForeground(new java.awt.Color(0, 0, 0));
        txt_apellidos.setBorder(null);

        txt_dni.setBackground(new java.awt.Color(192, 133, 82));
        txt_dni.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_dni.setForeground(new java.awt.Color(0, 0, 0));
        txt_dni.setBorder(null);

        txt_password.setBackground(new java.awt.Color(192, 133, 82));
        txt_password.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_password.setForeground(new java.awt.Color(0, 0, 0));
        txt_password.setBorder(null);
        txt_password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_passwordActionPerformed(evt);
            }
        });

        rb_masculino.setBackground(new java.awt.Color(243, 233, 220));
        genero.add(rb_masculino);
        rb_masculino.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rb_masculino.setForeground(new java.awt.Color(94, 48, 35));
        rb_masculino.setText("MASCULINO");

        rb_femenino.setBackground(new java.awt.Color(243, 233, 220));
        genero.add(rb_femenino);
        rb_femenino.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rb_femenino.setForeground(new java.awt.Color(94, 48, 35));
        rb_femenino.setText("FEMENINO");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lb_nombre)
                                    .addComponent(lb_contraseña))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lb_genero)
                                    .addComponent(lb_dni)
                                    .addComponent(lb_apellidos)))
                            .addComponent(lb_usuario))
                        .addGap(16, 16, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txt_usuario, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_nombre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 271, Short.MAX_VALUE)
                            .addComponent(txt_apellidos, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 271, Short.MAX_VALUE)
                            .addComponent(txt_dni, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 271, Short.MAX_VALUE)
                            .addComponent(txt_password, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(rb_masculino)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(rb_femenino))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_cancelar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_registrar)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_usuario)
                    .addComponent(txt_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lb_contraseña)
                    .addComponent(txt_password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lb_nombre)
                    .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_apellidos)
                    .addComponent(txt_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_dni)
                    .addComponent(txt_dni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_genero)
                    .addComponent(rb_masculino)
                    .addComponent(rb_femenino))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_registrar)
                    .addComponent(btn_cancelar))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_btn_cancelarActionPerformed

    private void txt_passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_passwordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_passwordActionPerformed

    private void btn_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarActionPerformed
        iUsuarioDao uDao = new UsuarioDaoImpl();
        usuario u = new usuario();
        if (txt_usuario.getText().trim().isEmpty()
                || txt_password.getText().trim().isEmpty()
                || txt_nombre.getText().trim().isEmpty()
                || txt_apellidos.getText().trim().isEmpty()
                || txt_dni.getText().trim().isEmpty()
                || !rb_masculino.isSelected() && !rb_femenino.isSelected()) {
            JOptionPane.showMessageDialog(null, "Por favor complete todos los campos",
                    "Mensaje Informativo",JOptionPane.WARNING_MESSAGE);
        }
        u.setUsuario(txt_usuario.getText().trim());
        u.setClave(txt_password.getText().trim());
        u.setNombre(txt_nombre.getText().trim());
        u.setApellidos(txt_apellidos.getText().trim());
        u.setDni(txt_dni.getText().trim());
        String genero = rb_masculino.isSelected()?"M":"F";
        u.setGenero(genero);
        
        System.out.println("Usuario: "+u.getUsuario()+
                           "\nClave: "+u.getClave()+
                           "\nNombre: "+u.getNombre()+
                           "\nApellidos: "+u.getApellidos()+
                           "\nDNI: "+u.getDni()+
                           "\nGenero: "+u.getGenero());
        
        boolean result = uDao.insertar(u);
        if (result) {
            JOptionPane.showMessageDialog(null, "Regsitro de usuario satisfactorio",
                    "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Registro de usuario fallido",
                    "Mensaje Informativo",JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_btn_registrarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(agregarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(agregarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(agregarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(agregarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new agregarUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JButton btn_registrar;
    private javax.swing.ButtonGroup genero;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lb_apellidos;
    private javax.swing.JLabel lb_contraseña;
    private javax.swing.JLabel lb_dni;
    private javax.swing.JLabel lb_genero;
    private javax.swing.JLabel lb_nombre;
    private javax.swing.JLabel lb_usuario;
    private javax.swing.JRadioButton rb_femenino;
    private javax.swing.JRadioButton rb_masculino;
    private javax.swing.JTextField txt_apellidos;
    private javax.swing.JTextField txt_dni;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JTextField txt_usuario;
    // End of variables declaration//GEN-END:variables
}
