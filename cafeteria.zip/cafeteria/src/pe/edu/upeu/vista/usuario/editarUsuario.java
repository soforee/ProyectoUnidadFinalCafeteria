
package pe.edu.upeu.vista.usuario;

import javax.swing.JOptionPane;
import pe.edu.upeu.implementation.UsuarioDaoImpl;
import pe.edu.upeu.interfaces.iUsuarioDao;
import pe.edu.upeu.model.usuario;

public class editarUsuario extends javax.swing.JFrame {
    int idUsuario;
    iUsuarioDao uDao = new UsuarioDaoImpl();

    public editarUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
        System.out.println("Id de usuario que se recibe: "+idUsuario);
        initComponents();
        buscarUsuario(idUsuario);
    }
    public void buscarUsuario(int idUsuario) {
        usuario u = uDao.BuscarPorId(idUsuario);
        try {
            txt_usuario_editado.setText(u.getUsuario());
            txt_password_editado.setText(u.getClave());
            txt_nombre_editado.setText(u.getNombre());
            txt_apellidos_editado.setText(u.getApellidos());
            txt_dni_editado.setText(u.getDni());
            if (u.getGenero().equalsIgnoreCase("M")) {
                rb_masculino_editado.setSelected(true);
            } else if (u.getGenero().equalsIgnoreCase("F")){
                rb_femenino_editado.setSelected(true);
            } else {
                genero_editado.clearSelection();
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los datos de usuario",
                    "Mensaje Informativo",JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        genero_editado = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lb_usuario = new javax.swing.JLabel();
        lb_contraseña = new javax.swing.JLabel();
        lb_nombre = new javax.swing.JLabel();
        lb_apellidos = new javax.swing.JLabel();
        lb_dni = new javax.swing.JLabel();
        lb_genero = new javax.swing.JLabel();
        btn_registrar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();
        txt_usuario_editado = new javax.swing.JTextField();
        txt_nombre_editado = new javax.swing.JTextField();
        txt_apellidos_editado = new javax.swing.JTextField();
        txt_dni_editado = new javax.swing.JTextField();
        txt_password_editado = new javax.swing.JPasswordField();
        rb_masculino_editado = new javax.swing.JRadioButton();
        rb_femenino_editado = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(94, 48, 35));

        jPanel2.setBackground(new java.awt.Color(243, 233, 220));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Editar Usuario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18), new java.awt.Color(94, 48, 35))); // NOI18N
        jPanel2.setForeground(new java.awt.Color(243, 233, 220));

        lb_usuario.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_usuario.setForeground(new java.awt.Color(137, 87, 55));
        lb_usuario.setText("USUARIO            : ");

        lb_contraseña.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_contraseña.setForeground(new java.awt.Color(137, 87, 55));
        lb_contraseña.setText("CONTRASEÑA    :");

        lb_nombre.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_nombre.setForeground(new java.awt.Color(137, 87, 55));
        lb_nombre.setText("NOMBRE            :");

        lb_apellidos.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_apellidos.setForeground(new java.awt.Color(137, 87, 55));
        lb_apellidos.setText("APELLIDO           :");

        lb_dni.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_dni.setForeground(new java.awt.Color(137, 87, 55));
        lb_dni.setText("DNI                      :");

        lb_genero.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lb_genero.setForeground(new java.awt.Color(137, 87, 55));
        lb_genero.setText("GENERO             :");

        btn_registrar.setBackground(new java.awt.Color(94, 48, 35));
        btn_registrar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_registrar.setForeground(new java.awt.Color(0, 0, 0));
        btn_registrar.setText("EDIT");
        btn_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrarActionPerformed(evt);
            }
        });

        btn_cancelar.setBackground(new java.awt.Color(192, 133, 82));
        btn_cancelar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_cancelar.setForeground(new java.awt.Color(0, 0, 0));
        btn_cancelar.setText("CANCEL");
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });

        txt_usuario_editado.setBackground(new java.awt.Color(192, 133, 82));
        txt_usuario_editado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_usuario_editado.setForeground(new java.awt.Color(0, 0, 0));
        txt_usuario_editado.setBorder(null);

        txt_nombre_editado.setBackground(new java.awt.Color(192, 133, 82));
        txt_nombre_editado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_nombre_editado.setForeground(new java.awt.Color(0, 0, 0));
        txt_nombre_editado.setBorder(null);

        txt_apellidos_editado.setBackground(new java.awt.Color(192, 133, 82));
        txt_apellidos_editado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_apellidos_editado.setForeground(new java.awt.Color(0, 0, 0));
        txt_apellidos_editado.setBorder(null);

        txt_dni_editado.setBackground(new java.awt.Color(192, 133, 82));
        txt_dni_editado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_dni_editado.setForeground(new java.awt.Color(0, 0, 0));
        txt_dni_editado.setBorder(null);

        txt_password_editado.setBackground(new java.awt.Color(192, 133, 82));
        txt_password_editado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_password_editado.setForeground(new java.awt.Color(0, 0, 0));
        txt_password_editado.setBorder(null);
        txt_password_editado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_password_editadoActionPerformed(evt);
            }
        });

        rb_masculino_editado.setBackground(new java.awt.Color(243, 233, 220));
        genero_editado.add(rb_masculino_editado);
        rb_masculino_editado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rb_masculino_editado.setForeground(new java.awt.Color(94, 48, 35));
        rb_masculino_editado.setText("MASCULINO");

        rb_femenino_editado.setBackground(new java.awt.Color(243, 233, 220));
        genero_editado.add(rb_femenino_editado);
        rb_femenino_editado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rb_femenino_editado.setForeground(new java.awt.Color(94, 48, 35));
        rb_femenino_editado.setText("FEMENINO");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lb_nombre)
                                    .addComponent(lb_contraseña))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lb_genero)
                                    .addComponent(lb_dni)
                                    .addComponent(lb_apellidos)))
                            .addComponent(lb_usuario))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(rb_masculino_editado)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(rb_femenino_editado)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_usuario_editado, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_password_editado, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_nombre_editado, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_apellidos_editado, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_dni_editado, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_cancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(btn_registrar)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_usuario)
                    .addComponent(txt_usuario_editado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_contraseña)
                    .addComponent(txt_password_editado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_nombre)
                    .addComponent(txt_nombre_editado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_apellidos)
                    .addComponent(txt_apellidos_editado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_dni)
                    .addComponent(txt_dni_editado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_genero)
                    .addComponent(rb_masculino_editado)
                    .addComponent(rb_femenino_editado))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_registrar)
                    .addComponent(btn_cancelar))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrarActionPerformed
        iUsuarioDao uDao = new UsuarioDaoImpl();
        usuario u = new usuario();
        if (txt_usuario_editado.getText().trim().isEmpty()
            || txt_password_editado.getText().trim().isEmpty()
            || txt_nombre_editado.getText().trim().isEmpty()
            || txt_apellidos_editado.getText().trim().isEmpty()
            || txt_dni_editado.getText().trim().isEmpty()
            || !rb_masculino_editado.isSelected() && !rb_femenino_editado.isSelected()) {
            JOptionPane.showMessageDialog(null, "Por favor complete todos los campos",
                "Mensaje Informativo",JOptionPane.WARNING_MESSAGE);
        }
        u.setUsuario(txt_usuario_editado.getText().trim());
        u.setClave(txt_password_editado.getText().trim());
        u.setNombre(txt_nombre_editado.getText().trim());
        u.setApellidos(txt_apellidos_editado.getText().trim());
        u.setDni(txt_dni_editado.getText().trim());
        String genero = rb_masculino_editado.isSelected()?"M":"F";
        u.setGenero(genero);
        u.setIdusuario(idUsuario);

        System.out.println("Usuario: "+u.getUsuario()+
            "\nClave: "+u.getClave()+
            "\nNombre: "+u.getNombre()+
            "\nApellidos: "+u.getApellidos()+
            "\nDNI: "+u.getDni()+
            "\nGenero: "+u.getGenero());

        boolean result = uDao.editar(u);
        if (result) {
            JOptionPane.showMessageDialog(null, "Registro de usuario satisfactorio",
                "Mensaje Informativo",JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Registro de usuario fallido",
                "Mensaje Informativo",JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btn_registrarActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_btn_cancelarActionPerformed

    private void txt_password_editadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_password_editadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_password_editadoActionPerformed

//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(editarUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(editarUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(editarUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(editarUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new editarUser().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JButton btn_registrar;
    private javax.swing.ButtonGroup genero_editado;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lb_apellidos;
    private javax.swing.JLabel lb_contraseña;
    private javax.swing.JLabel lb_dni;
    private javax.swing.JLabel lb_genero;
    private javax.swing.JLabel lb_nombre;
    private javax.swing.JLabel lb_usuario;
    private javax.swing.JRadioButton rb_femenino_editado;
    private javax.swing.JRadioButton rb_masculino_editado;
    private javax.swing.JTextField txt_apellidos_editado;
    private javax.swing.JTextField txt_dni_editado;
    private javax.swing.JTextField txt_nombre_editado;
    private javax.swing.JPasswordField txt_password_editado;
    private javax.swing.JTextField txt_usuario_editado;
    // End of variables declaration//GEN-END:variables
}
