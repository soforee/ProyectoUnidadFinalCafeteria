
package pe.edu.upeu.implementation;

import java.util.List;
import pe.edu.upeu.interfaces.iCatalogoDao;
import pe.edu.upeu.model.catalogo;
import java.sql.*;
import java.util.ArrayList;
import pe.edu.upeu.utils.ConexionBD;

public class CatalogoDaoImpl implements iCatalogoDao{

    private Connection cn;

    @Override
    public boolean insertar(catalogo ca) {
        boolean flag = false;
        PreparedStatement st;

        String query = null;
        try {
            query = "INSERT INTO catalogo(nameProduct, tipo, precio)"
                    + "VALUES(?,?,?)";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setString(1, ca.getNameProduct());
            st.setString(2, ca.getTipo());
            st.setDouble(3, ca.getPrecio());
            st.executeUpdate();
            flag = true;
        } catch (Exception e) {
            System.out.println("Error de inserccion" + e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            flag = false;
        } finally {
            if (cn != null) {
                try {

                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion" + e.getMessage());
                }
            }
        }
        return flag;
    }

    @Override
    public List<catalogo> listar() {
        List<catalogo> lista = null;
        catalogo ca;
        PreparedStatement st;
        ResultSet rs;
        String query = null;
        try {
            query = "SELECT * FROM catalogo";
            lista = new ArrayList<>();
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            rs = st.executeQuery();
            while (rs.next()) {
                ca = new catalogo();
                ca.setIdproducto(rs.getInt("idproducto"));
                ca.setNameProduct(rs.getString("nameProduct"));
                ca.setTipo(rs.getString("tipo"));
                ca.setPrecio(rs.getDouble("precio"));
                lista.add(ca);
            }
        } catch (Exception e) {
            System.out.println("Error de lista en el catalogo" + e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
        } finally {
            if (cn != null) {
                try {

                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion" + e.getMessage());
                }
            }
        }
        return lista;
    }

    @Override
    public boolean editar(catalogo ca) {
        boolean flag = false;
        PreparedStatement st;
        String query = null;
        try {
            query = "UPDATE catalogo SET nameProduct = ?, tipo = ?, precio = ? WHERE idproducto = ?";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setString(1, ca.getNameProduct());
            st.setString(2, ca.getTipo());
            st.setDouble(3, ca.getPrecio());
            st.setInt(4, ca.getIdproducto());
            st.executeUpdate();
            flag = true;
        } catch (Exception e) {
            System.out.println("Error al actualizar el catalogo" + e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            flag = false;
            System.out.println("¡Error!, no se pudo actualizar el registro");
        } finally {
            if (cn != null) {
                try {

                } catch (Exception e) {
                    System.out.println("Error al cerrar la conexion" + e.getMessage());
                }
            }
        }
        return flag;
    }

    @Override
    public boolean eliminar(catalogo ca) {
        boolean flag = false;
        PreparedStatement st;
        String query = null;
        try {
            query = "DELETE FROM catalogo WHERE idproducto = ?";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setInt(1, ca.getIdproducto());
            st.executeUpdate();
            flag = true;
        } catch (Exception e) {
            System.out.println("Error al eliminar un producto del catalogo" + e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            flag = false;
            System.out.println("¡Error!, no se pudo eliminar un producto del catalogo por ID");
        } finally {
            if (cn != null) {
                try {

                } catch (Exception e) {
                    System.out.println("Error al cerrar la conexion" + e.getMessage());
                }
            }
        }
        return flag;
    }

    @Override
    public catalogo BuscarPorId(int id) {
        catalogo ca = null;
        PreparedStatement st;
        ResultSet rs;
        String query = null;
        try {
            query = "SELECT * FROM catalogo WHERE idproducto = ?";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setInt(1, id);
            rs = st.executeQuery();
            if (rs.next()) {
                ca = new catalogo();
                ca.setIdproducto(rs.getInt("idproducto"));
                ca.setNameProduct(rs.getString("nameProduct"));
                ca.setTipo(rs.getString("tipo"));
                ca.setPrecio(rs.getDouble("precio"));
            }
        } catch (Exception e) {
            System.out.println("Error de busqueda en el catalogo" + e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
        } finally {
            if (cn != null) {
                try {

                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion" + e.getMessage());
                }
            }
        }
        return ca;
    }
}
