
package pe.edu.upeu.implementation;

import pe.edu.upeu.interfaces.iPedidoDao;
import pe.edu.upeu.model.pedido;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import pe.edu.upeu.utils.ConexionBD;

public class PedidoDaoImpl implements iPedidoDao{
    
    private Connection cn;

    @Override
    public boolean insertar(pedido p) {
        boolean flag = false;
        PreparedStatement st;
        String query = null;
        try {
            query = "INSERT INTO pedido(mesa, total, estado, fecha)"
                  + "VALUES(?,?,?,?)";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setInt(1, p.getMesa());
            st.setDouble(2, p.getTotal());
            st.setString(3, p.getEstado());
            st.setString(4, p.getFecha());
            st.executeUpdate();
            flag = true;
        } catch (Exception e) {
            System.out.println("Error de inserccion "+e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            flag = false;
        } finally {
            if (cn!=null) {
                try {
                    
                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion "+e.getMessage());
                }
            }
        }
        return flag;
    }

    @Override
    public List<pedido> listar() {
        List<pedido> lista = null;
        pedido pe;
        PreparedStatement st;
        ResultSet rs;
        String query = null;
        try {
            query = "SELECT * FROM pedido";
            lista = new ArrayList<>();
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            rs = st.executeQuery();
            while (rs.next()) {                
                pe = new pedido();
                pe.setIdpedido(rs.getInt("idpedido"));
                pe.setMesa(rs.getInt("mesa"));
                pe.setTotal(rs.getDouble("total"));
                pe.setEstado(rs.getString("estado"));
                pe.setFecha(rs.getString("fecha"));
                lista.add(pe);
            }
        } catch (Exception e) {
            System.out.println("Error de lista en el pedido "+e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
        } finally {
            if (cn!=null) {
                try {
                    
                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion "+e.getMessage());
                }
            }
        }
        return lista;
    }

    @Override
    public boolean editar(pedido p) {
        boolean flag = false;
        PreparedStatement st;
        String query = null;
        try {
            query = "UPDATE pedido SET mesa = ?, total = ?, estado = ?, fecha = ? WHERE idpedido = ?";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setInt(1, p.getMesa());
            st.setDouble(2, p.getTotal());
            st.setString(3, p.getEstado());
            st.setString(4, p.getFecha());
            st.setInt(5, p.getIdpedido());
            st.executeUpdate();
            flag = true;    
        } catch (Exception e) {
            System.out.println("Error al actualizar un pedido "+e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            flag = false;
            System.out.println("Error, no se pudo actualizar el pedido");
        } finally {
            if (cn!= null) {
                try {
                    
                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion "+e.getMessage());
                }
            }
        }
        return flag;
    }

    @Override
    public boolean eliminar(pedido p) {
        boolean flag = false;
        PreparedStatement st;
        String query = null;
        try {
            query = "DELETE FROM pedido WHERE idpedido = ?";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setInt(1, p.getIdpedido());
            st.executeUpdate();
            flag = true;
        } catch (Exception e) {
            System.out.println("Error al eliminar el pedido "+e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            flag = false;
            System.out.println("Error, no se pudo eliminar el pedido por ID");
        } finally {
            if (cn!= null) {
                try {
                    
                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion "+e.getMessage());
                }
            }
        }
        return flag;
    }

    @Override
    public pedido BuscarPorId(int id) {
        pedido pe = null;
        PreparedStatement st;
        ResultSet rs;
        String query = null;
        try {
            query = "SELECT * FROM pedido WHERE idpedido = ?";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setInt(1, id);
            rs = st.executeQuery();
            if (rs.next()) {
                pe = new pedido();
                pe.setIdpedido(rs.getInt("idpedido"));
                pe.setMesa(rs.getInt("mesa"));
                pe.setTotal(rs.getDouble("total"));
                pe.setEstado(rs.getString("estado"));
                pe.setFecha(rs.getString("fecha"));
            }
        } catch (Exception e) {
            System.out.println("Error de busqueda del pedido "+e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
        } finally {
            if (cn!=null) {
                try {
                    
                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion "+e.getMessage());
                }
            }
        }
        return pe;
    }
}
