
package pe.edu.upeu.implementation;

import java.sql.PreparedStatement;
import java.util.List;
import pe.edu.upeu.interfaces.iUsuarioDao;
import pe.edu.upeu.model.usuario;
import pe.edu.upeu.utils.ConexionBD;
import java.sql.*;
import java.util.ArrayList;

public class UsuarioDaoImpl implements iUsuarioDao{
    private Connection cn;

    @Override
    public boolean insertar(usuario u) {
        boolean flag = false;
        PreparedStatement st;
        
        String query = null;
        try {
            query = "INSERT INTO usuario(usuario, clave, nombre, apellidos, dni, genero)"
                  + "VALUES(?,?,?,?,?,?)";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setString(1, u.getUsuario());
            st.setString(2, u.getClave());
            st.setString(3, u.getNombre());
            st.setString(4, u.getApellidos());
            st.setString(5, u.getDni());
            st.setString(6, u.getGenero());
            //ejecutar la consulta de inseccion
            st.executeUpdate();
            flag = true;
        } catch (Exception e) {
            System.out.println("Error de inserccion"+e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            flag = false;
        } finally {
            if (cn!= null) {
                try {
                    
                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion"+e.getMessage());
                }
            }
        }
        return flag;
    }

    @Override
    public List<usuario> listar() {
        List<usuario> lista = null;
        usuario us;
        PreparedStatement st;
        ResultSet rs;
        String query = null;
        try {
            query = "SELECT * FROM usuario";
            lista = new ArrayList<>();
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            rs = st.executeQuery();
            while (rs.next()) {
                us = new usuario();
                us.setIdusuario(rs.getInt("idusuario"));
                us.setUsuario(rs.getString("usuario"));
                us.setClave(rs.getString("clave"));
                us.setNombre(rs.getString("nombre"));
                us.setApellidos(rs.getString("apellidos"));
                us.setDni(rs.getString("dni"));
                us.setGenero(rs.getString("genero"));
                lista.add(us);
            }
            
        } catch (Exception e) {
            System.out.println("Error de lista de usuario"+e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            
        } finally {
            if (cn!= null) {
                try {
                    
                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion"+e.getMessage());
                }
            }
        }
        return lista;
    }

    @Override
    public boolean editar(usuario u) {
        boolean flag = false;
        PreparedStatement st;
        String query = null;
        try {
            query = "UPDATE usuario SET usuario = ?, clave = ?, nombre = ?, apellidos = ?, dni = ?,  genero = ? WHERE idusuario = ?;";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setString(1, u.getUsuario());
            st.setString(2, u.getClave());
            st.setString(3, u.getNombre());
            st.setString(4, u.getApellidos());
            st.setString(5, u.getDni());
            st.setString(6, u.getGenero());
            st.setInt(7, u.getIdusuario());
            st.executeUpdate();
            flag = true;
        } catch (Exception e) {
            System.out.println("¡Error al actualizar un usuario!" + e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            flag = false;
            System.out.println("¡Error!, No se pudo actualizar el registro");
        } finally {
            if (cn != null) {
                try {
                } catch (Exception e) {
                    System.out.println("Error al cerrar la conexión: " + e.getMessage());
                }
            }
        }
        return flag;
    }

    @Override
    public boolean eliminar(usuario u) {
        boolean flag = false;
        PreparedStatement st;
        String query = null;
        try {
            query = "DELETE FROM usuario WHERE idusuario = ?";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setInt(1, u.getIdusuario());
            st.executeUpdate();
            flag = true;
        } catch (Exception e) {
            System.out.println("Error al eliminar un usuario" + e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            flag = false;
            System.out.println("Error, No se pudo eliminar un usuario por ID");
        } finally {
            if (cn != null) {
                try {
                } catch (Exception e) {
                    System.out.println("Error al cerrar la conexión: " + e.getMessage());
                }
            }
        }
        return flag;
    }

    @Override
    public usuario BuscarPorId(int id) {
        usuario us = null;
        PreparedStatement st;
        ResultSet rs;
        String query = null;
        try {
            query = "SELECT * FROM usuario WHERE idusuario=?;";
            cn = ConexionBD.getConnection();
            st = cn.prepareStatement(query);
            st.setInt(1, id);
            rs = st.executeQuery();
            if (rs.next()) {
                us = new usuario();
                us.setIdusuario(rs.getInt("idusuario"));
                us.setUsuario(rs.getString("usuario"));
                us.setClave(rs.getString("clave"));
                us.setNombre(rs.getString("nombre"));
                us.setApellidos(rs.getString("apellidos"));
                us.setDni(rs.getString("dni"));
                us.setGenero(rs.getString("genero"));
            }
            
        } catch (Exception e) {
            System.out.println("Error de busqueda del usuario"+e.getMessage());
            try {
                cn.rollback();
            } catch (Exception ex) {
            }
            
        } finally {
            if (cn!= null) {
                try {
                    
                } catch (Exception e) {
                    System.out.println("Error al cerrar la inserccion"+e.getMessage());
                }
            }
        }
        return us;
    }
}
