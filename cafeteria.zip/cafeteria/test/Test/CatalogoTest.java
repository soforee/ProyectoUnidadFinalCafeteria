
package Test;

import java.util.List;
import pe.edu.upeu.implementation.CatalogoDaoImpl;
import pe.edu.upeu.interfaces.iCatalogoDao;
import pe.edu.upeu.model.catalogo;

public class CatalogoTest {
    
    static iCatalogoDao ca = new CatalogoDaoImpl();

    public static void main(String[] args) {
        CatalogoTest ct = new CatalogoTest();
        ct.listarProductoPorId();
    }
    public void insertar(){
        catalogo c = new catalogo();
        c.setNameProduct("Cafe Espresso");
        c.setTipo("Bebida");
        c.setPrecio(8);
        
        boolean result = ca.insertar(c);
        if (result) {
            System.out.println("Registro satisfactorio");
        } else {
            System.out.println("Error en el registro");
        }
    }
    public void listar(){
        List<catalogo> lista = ca.listar();
        if (lista != null && !lista.isEmpty()) {
            for (catalogo catalogo : lista) {
                System.out.println("ID Producto : "+catalogo.getIdproducto()+
                                   "\nNombre Producto: "+catalogo.getNameProduct()+
                                   "\nTipo: "+catalogo.getTipo()+
                                   "\nPrecio: "+catalogo.getPrecio());
            }
        } else {
            System.out.println("No hay regsitros en el catalogo");
        }
    }
    public void eliminar(){
        catalogo c = new catalogo();
        c.setIdproducto(1);
        boolean result = ca.eliminar(c);
        if (result) {
            System.out.println("Registro de catalogo eliminado");
        } else {
            System.out.println("Error al eliminar el registro");
        }
    }
    public void editar(){
        catalogo c = new catalogo();
            c.setNameProduct("Cafe Capuccino");
            c.setTipo("Bebida");
            c.setPrecio(10);
            c.setIdproducto(1);
            
            boolean result = ca.editar(c);
            if (result) {
                System.out.println("Catalogo actualizado");
        } else {
                System.out.println("Error de actualziacion en el catalogo");
        }
    }
    public void listarProductoPorId(){
        catalogo catalogo = ca.BuscarPorId(1);
        if (catalogo != null) {
            System.out.println("ID Producto: "+catalogo.getIdproducto()+
                               "\nNombre Prodcuto: "+catalogo.getNameProduct()+
                               "\nTipo: "+catalogo.getTipo()+
                               "\nPrecio: "+catalogo.getPrecio());
        } else {
            System.out.println("No hay registros en el catalogo");
        }
    }
}
