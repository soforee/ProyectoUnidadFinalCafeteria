
package Test;

import java.util.List;
import pe.edu.upeu.implementation.PedidoDaoImpl;
import pe.edu.upeu.interfaces.iPedidoDao;
import pe.edu.upeu.model.pedido;

public class PedidoTest {
    
    static iPedidoDao pe = new PedidoDaoImpl();

    public static void main(String[] args) {
       PedidoTest t = new PedidoTest();
        t.insertar();
    }
    public void insertar(){
        pedido p = new pedido();
        p.setMesa(1);
        p.setTotal(123);
        p.setEstado("Pagado");
        p.setFecha("28/10/2025");
        boolean result = pe.insertar(p);
        if (result) {
            System.out.println("Registro success");
        } else {
            System.out.println("Error en el registro");
        }
    }
    public void listar(){
        List<pedido> lista = pe.listar();
        if (lista != null && !lista.isEmpty()) {
            for (pedido pedido : lista) {
                System.out.println("ID Pedido: "+pedido.getIdpedido()+
                                   "\nMesa: "+pedido.getMesa()+
                                   "\nTotal: "+pedido.getTotal()+
                                   "\nEstado: "+pedido.getEstado()+
                                   "\nFecha: "+pedido.getFecha());
            }
        } else {
            System.out.println("No hay resgistros");
        }
    }
    public void eliminar(){
        pedido p = new pedido();
        p.setIdpedido(1);
        boolean result = pe.eliminar(p);
        if (result) {
            System.out.println("Resgistro de pedido eliminado");
        } else {
            System.out.println("Error al eliminar pedido");
        }
    }
    public void editar(){
        pedido p = new pedido();
        p.setMesa(2);
        p.setTotal(95);
        p.setEstado("En proceso");
        p.setFecha("27/10/2025");
        p.setIdpedido(1);
        boolean result = pe.editar(p);
        if (result) {
            System.out.println("Registro de pedido actualizado");
        } else {
            System.out.println("Error de actualizacion del pedido");
        }
    }
    public void listarPedidoPorId(){
        pedido pedido = pe.BuscarPorId(1);
        if (pedido != null) {
            System.out.println("ID Pedido: "+pedido.getIdpedido()+
                               "\nMesa: "+pedido.getMesa()+
                               "\nTotal: "+pedido.getTotal()+
                               "\nEstado: "+pedido.getEstado()+
                               "\nFecha: "+pedido.getFecha());
        } else {
            System.out.println("No hay resgistros de pedido");
        }
    } 
    
    
}
