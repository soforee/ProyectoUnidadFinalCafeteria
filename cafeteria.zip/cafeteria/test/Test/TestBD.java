    
package Test;

import java.sql.Connection;
import pe.edu.upeu.utils.ConexionBD;

public class TestBD {

    public static void main(String[] args) {
        TestBD t = new TestBD();
        t.testConexion();
    }
    public void testConexion(){
        ConexionBD c = new ConexionBD();
        try {
            Connection conn = c.getConnection();
            if (conn != null && !conn.isClosed()) {
                System.out.println("Conexion satisfactoria");
            }else {
                System.out.println("Conexion fallida");
            }
        } catch (Exception e) {
            System.out.println("Error de conexion" + e.getMessage());
            e.printStackTrace();
        }
    }
}
    

