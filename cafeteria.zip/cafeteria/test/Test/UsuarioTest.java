
package Test;

import java.util.List;
import pe.edu.upeu.implementation.UsuarioDaoImpl;
import pe.edu.upeu.interfaces.iUsuarioDao;
import pe.edu.upeu.model.usuario;

public class UsuarioTest {
    
    static iUsuarioDao us = new UsuarioDaoImpl();

    public static void main(String[] args) {
        
        UsuarioTest ut = new UsuarioTest();
        ut.insertar();
    }

    public void insertar() {
        usuario u = new usuario();
        u.setUsuario("StarDollar");
        u.setClave("dodo09314");
        u.setNombre("Doriann");
        u.setApellidos("Gonzales");
        u.setDni("61035577");
        u.setGenero("M");

        boolean result = us.insertar(u);
        if (result) {
            System.out.println("Registro success");
        } else {
            System.out.println("Error en el registro");
        }
    }

    public void listar() {
        List<usuario> lista = us.listar();
        if (lista != null && !lista.isEmpty()) {
            for (usuario usuario : lista) {
                System.out.println("ID CLIENTE: " + usuario.getIdusuario());
                System.out.println("USUARIO: " + usuario.getUsuario());
                System.out.println("CLAVE: " + usuario.getClave());
                System.out.println("NOMBRE: " + usuario.getNombre());
                System.out.println("APELLIDOS: " + usuario.getApellidos());
                System.out.println("DNI: " + usuario.getDni());
                System.out.println("GENERO: " + usuario.getGenero());
            }
        } else {
            System.out.println("No hay resgistros");
        }
    }

    public void eliminar() {
        usuario u = new usuario();
        u.setIdusuario(4);
        boolean result = us.eliminar(u);
        if (result) {
            System.out.println("REsgistro eliminado");
        } else {
            System.out.println("Error al eliminar");
        }
    }

    public void editar() {
        usuario u = new usuario();
        u.setUsuario("Stardo");
        u.setClave("dod0934");
        u.setGenero("M");
        u.setNombre("Juan act");
        u.setApellidos("Perez act");
        u.setDni("12347678");
        u.setIdusuario(4);
        u.setGenero("M");

        boolean result = us.editar(u);
        if (result) {
            System.out.println("Registro actualizado");
        } else {
            System.out.println("Error de actualizacion");
        }
    }

    public void listarClientePorId() {
        usuario usuario = us.BuscarPorId(2);
        if (usuario != null) {
            System.out.println("ID USUARIO: " + usuario.getIdusuario());
            System.out.println("USUARIO: " + usuario.getUsuario());
            System.out.println("CLAVE: " + usuario.getClave());
            System.out.println("NOMBRE: " + usuario.getNombre());
            System.out.println("APELLIDOS: " + usuario.getApellidos());
            System.out.println("DNI: " + usuario.getDni());
            System.out.println("GENERO: " + usuario.getGenero());
        } else {
            System.out.println("No hay resgistros");
        }
    }
}
    
